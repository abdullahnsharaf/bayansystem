/**
 * Tamper demo — the "quietly editing logs" attack, made visible:
 *   npm run tamper
 *
 * Edits ONE field of ONE audit entry in .data/bayan.json (what a malicious
 * admin/DBA would do), then re-verifies the chain and prints where it broke.
 * Reload the auditor page afterwards: the integrity banner turns red at the
 * same event. Delete .data/bayan.json to reset the demo.
 */
import fs from "node:fs";
import path from "node:path";
import { verifyChain } from "../lib/server/db";
import type { Db } from "../lib/types";

const file = path.join(process.cwd(), ".data", "bayan.json");
if (!fs.existsSync(file)) {
  console.error("No .data/bayan.json yet — open the app (or run `npm run selftest`) first.");
  process.exit(1);
}

const db = JSON.parse(fs.readFileSync(file, "utf-8")) as Db;
if (db.audit.length < 2) {
  console.error("Audit trail too short to demo tampering.");
  process.exit(1);
}

const target = db.audit[1]; // the attacker edits event #2
const before = verifyChain(db.audit);
console.log("Before tampering:", JSON.stringify(before));

console.log(`Attacker quietly edits audit event #${target.seq} (${target.action})…`);
target.details = { ...target.details, amount: 999999, editedBy: "malicious-admin" };

fs.writeFileSync(file, JSON.stringify(db, null, 2), "utf-8");

const after = verifyChain(db.audit);
console.log("After tampering: ", JSON.stringify(after));
if (!after.ok) {
  console.log(
    `✓ Tamper-evidence works — the SHA-256 chain breaks at event #${after.brokenAt}. ` +
      "Reload the auditor page to see the red banner. Delete .data/bayan.json to reset."
  );
} else {
  console.error("✗ Chain still verifies — something is wrong.");
  process.exit(1);
}
