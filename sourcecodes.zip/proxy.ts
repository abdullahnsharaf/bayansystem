/**
 * BAYAN — Next.js 16 proxy: SERVER-SIDE page gating before anything renders.
 *
 * Each workspace requires its TideCloak realm role, verified against the
 * realm's keys from the kcToken cookie. This is defence-in-depth for UX —
 * every API route independently re-verifies the JWT in lib/server/auth.ts,
 * which is the real security boundary.
 */
import type { NextRequest } from "next/server";
import { NextResponse } from "next/server";
import { createTideCloakProxy } from "@tidecloak/nextjs/server";
import type { TidecloakConfig } from "@tidecloak/nextjs/server";
import rawConfig from "./tidecloak.json";

const tcConfig = rawConfig as TidecloakConfig;
const isConfigured =
  typeof (rawConfig as Record<string, unknown>)["auth-server-url"] === "string";

const tideProxy = isConfigured
  ? createTideCloakProxy({
      config: tcConfig,
      protectedRoutes: {
        "/applicant": ["applicant"],
        "/applicant/*": ["applicant"],
        "/officer": ["officer"],
        "/officer/*": ["officer"],
        "/auditor": ["auditor"],
        "/auditor/*": ["auditor"],
      },
      onFailure: (ctx: { token: string | null }, req: NextRequest) => {
        // No token at all → back to the landing page to sign in.
        if (!ctx.token) return NextResponse.redirect(new URL("/", req.url));
        // Authenticated but missing the role for this workspace.
        const url = new URL("/access-denied", req.url);
        url.searchParams.set("from", req.nextUrl.pathname);
        return NextResponse.redirect(url);
      },
      onError: (_err: unknown, req: NextRequest) =>
        NextResponse.redirect(new URL("/", req.url)),
    })
  : null;

export async function proxy(req: NextRequest) {
  // Until `npm run init` writes tidecloak.json, send everything to the setup screen.
  if (!tideProxy) return NextResponse.redirect(new URL("/", req.url));
  return tideProxy(req);
}

export const config = {
  matcher: ["/applicant/:path*", "/officer/:path*", "/auditor/:path*"],
};
