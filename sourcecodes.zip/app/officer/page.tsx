"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { AppShell } from "@/components/AppShell";
import { IdentityPanel } from "@/components/IdentityPanel";
import { Sim } from "@/components/Sim";
import { useApi } from "@/components/useApi";
import {
  COMPLIANT_PRODUCTS,
  type Application,
  type CompliantProduct,
  type DecisionAction,
} from "@/lib/types";

const STATUS_BADGE: Record<string, string> = {
  Pending: "b-pending",
  Approved: "b-approved",
  "Alternative offered": "b-alt",
  Declined: "b-declined",
};
const BAND_BADGE: Record<string, string> = { Low: "b-low", Moderate: "b-mod", High: "b-high" };
const VERDICT_BADGE: Record<string, string> = {
  Compliant: "b-compliant",
  "Needs review": "b-review",
  "Non-compliant": "b-noncompliant",
};

export default function OfficerPage() {
  const api = useApi();
  const [apps, setApps] = useState<Application[]>([]);
  const [tab, setTab] = useState<"pending" | "decided">("pending");
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [note, setNote] = useState("");
  const [alt, setAlt] = useState<CompliantProduct>("Tawarruq");
  const [lang, setLang] = useState<"en" | "ms">("en");
  const [deciding, setDeciding] = useState(false);
  const [msg, setMsg] = useState<{ kind: "ok" | "danger" | "warn"; text: string } | null>(null);

  const load = useCallback(async () => {
    const res = await api("/api/applications");
    if (res.ok) setApps(((await res.json()) as { applications: Application[] }).applications);
  }, [api]);

  useEffect(() => {
    void load();
  }, [load]);

  const pending = useMemo(() => apps.filter((a) => a.status === "Pending"), [apps]);
  const decided = useMemo(() => apps.filter((a) => a.status !== "Pending"), [apps]);
  const shown = tab === "pending" ? pending : decided;
  const selected = apps.find((a) => a.id === selectedId) ?? null;

  const select = (a: Application) => {
    setSelectedId(a.id);
    setNote("");
    setMsg(null);
    setAlt(a.assessment.shariah.suggestedAlternative ?? "Tawarruq");
  };

  const decide = async (action: DecisionAction) => {
    if (!selected) return;
    setDeciding(true);
    setMsg(null);
    try {
      const res = await api(`/api/applications/${selected.id}/decision`, {
        method: "POST",
        body: JSON.stringify({
          action,
          note,
          ...(action === "Alternative offered" ? { alternativeProduct: alt } : {}),
        }),
      });
      const data = await res.json();
      if (res.ok) {
        setMsg({ kind: "ok", text: `Decision recorded: ${action}.` });
        await load();
      } else if (res.status === 403) {
        setMsg({ kind: "danger", text: `BLOCKED (403): ${data.error}` });
        await load(); // the blocked attempt is now in the audit trail
      } else if (res.status === 422) {
        setMsg({ kind: "danger", text: `422: ${data.error}` });
      } else if (res.status === 409) {
        setMsg({ kind: "warn", text: `409: ${data.error}` });
        await load();
      } else {
        setMsg({ kind: "warn", text: String(data.error ?? `Error ${res.status}`) });
      }
    } catch (e) {
      setMsg({ kind: "danger", text: e instanceof Error ? e.message : "Network error" });
    } finally {
      setDeciding(false);
    }
  };

  const a = selected;
  const asmt = a?.assessment;
  const nonCompliant = asmt?.shariah.verdict === "Non-compliant";

  return (
    <AppShell
      active="/officer"
      title="Officer review"
      subtitle="You decide — the engine only explains. Segregation of duties and the Shariah gate are enforced by the server, not this page."
    >
      <div className="stats">
        <div className="stat">
          <div className="n">{pending.length}</div>
          <div className="l">Pending</div>
        </div>
        <div className="stat">
          <div className="n">{apps.filter((x) => x.status === "Approved").length}</div>
          <div className="l">Approved</div>
        </div>
        <div className="stat">
          <div className="n">{apps.filter((x) => x.status === "Alternative offered").length}</div>
          <div className="l">Alternatives offered</div>
        </div>
        <div className="stat">
          <div className="n">{apps.filter((x) => x.status === "Declined").length}</div>
          <div className="l">Declined</div>
        </div>
      </div>

      <div className="card">
        <div className="tabs">
          <button className={tab === "pending" ? "active" : ""} onClick={() => setTab("pending")}>
            Pending ({pending.length})
          </button>
          <button className={tab === "decided" ? "active" : ""} onClick={() => setTab("decided")}>
            Decided ({decided.length})
          </button>
        </div>
        <table className="tbl">
          <thead>
            <tr>
              <th>Ref</th>
              <th>Applicant</th>
              <th>Structure</th>
              <th>Amount</th>
              <th>Score</th>
              <th>Shariah</th>
              <th>Engine rec. </th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {shown.map((x) => (
              <tr
                key={x.id}
                className={`app-row ${x.id === selectedId ? "selected" : ""}`}
                onClick={() => select(x)}
              >
                <td className="mono">{x.id}</td>
                <td>
                  {x.input.fullName}
                  <div className="muted">{x.ownerUsername}</div>
                </td>
                <td>{x.input.product}</td>
                <td>RM{x.input.amount.toLocaleString()}</td>
                <td>
                  {x.assessment.score}{" "}
                  <span className={`badge ${BAND_BADGE[x.assessment.band]}`}>{x.assessment.band}</span>
                </td>
                <td>
                  <span className={`badge ${VERDICT_BADGE[x.assessment.shariah.verdict]}`}>
                    {x.assessment.shariah.verdict}
                  </span>
                </td>
                <td>
                  {x.assessment.injection.flagged ? (
                    <span className="badge b-noncompliant">⚠ injection</span>
                  ) : (
                    x.assessment.recommendation
                  )}
                </td>
                <td>
                  <span className={`badge ${STATUS_BADGE[x.status]}`}>{x.status}</span>
                </td>
              </tr>
            ))}
            {shown.length === 0 ? (
              <tr>
                <td colSpan={8} className="muted">
                  Nothing here.
                </td>
              </tr>
            ) : null}
          </tbody>
        </table>
        <p className="muted" style={{ marginBottom: 0 }}>
          Demo applicants are seeded <Sim label="DEMO DATA" /> — select a row to open the full
          assessment.
        </p>
      </div>

      {a && asmt ? (
        <div className="card">
          <h3>
            {a.id} — {a.input.fullName}{" "}
            <span className={`badge ${STATUS_BADGE[a.status]}`}>{a.status}</span>
          </h3>

          {asmt.injection.flagged ? (
            <div className="alert alert-danger">
              <b>⚠ AI-input guard: prompt-injection patterns detected.</b> The AI narrative has
              been suppressed and the engine forced <b>Manual review</b> — hostile applicant text
              must never steer an automated outcome.
              <ul style={{ margin: "6px 0 0" }}>
                {asmt.injection.matches.map((m, i) => (
                  <li key={i}>
                    [{m.language} · {m.label}] <code>&ldquo;{m.sample}&rdquo;</code>
                  </li>
                ))}
              </ul>
            </div>
          ) : null}

          <div className="grid2">
            <div>
              <dl className="kv">
                <dt>Occupation</dt>
                <dd>{a.input.occupation}</dd>
                <dt>Structure</dt>
                <dd>{a.input.product}</dd>
                <dt>Amount / tenure</dt>
                <dd>
                  RM{a.input.amount.toLocaleString()} over {a.input.tenureMonths} months
                </dd>
                <dt>
                  Est. instalment <Sim label="SIM PRICING" />
                </dt>
                <dd>RM{asmt.instalment.toLocaleString()}/month</dd>
                <dt>Declared income</dt>
                <dd>RM{a.input.monthlyIncome.toLocaleString()}/month</dd>
                <dt>Commitments</dt>
                <dd>RM{a.input.monthlyCommitments.toLocaleString()}/month</dd>
                <dt>DSR</dt>
                <dd>{(asmt.dsr * 100).toFixed(1)}%</dd>
                <dt>Income history</dt>
                <dd>{a.input.incomeHistoryMonths} months</dd>
                <dt>E-wallet inflow</dt>
                <dd>RM{a.input.ewalletMonthlyInflow.toLocaleString()}/month</dd>
                <dt>Purpose</dt>
                <dd>{a.input.purpose}</dd>
              </dl>
            </div>
            <div>
              <div className="score-wrap">
                <div className="score-big">{asmt.score}</div>
                <div>
                  <span className={`badge ${BAND_BADGE[asmt.band]}`}>{asmt.band} risk</span>
                  <div className="muted">
                    Engine recommendation: <b>{asmt.recommendation}</b>
                  </div>
                  <div className="muted">
                    Alternative-data score (300–850) <Sim label="RULES ENGINE — SIMULATED" />
                  </div>
                </div>
              </div>
              <hr className="hr-soft" />
              {asmt.factors.map((f, i) => (
                <div className="factor" key={i}>
                  <div className={`pts ${f.points >= 0 ? "pos" : "neg"}`}>
                    {f.points >= 0 ? `+${f.points}` : f.points}
                  </div>
                  <div>
                    <span className="lbl">{f.label}</span>{" "}
                    <span className="note">{f.note}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <hr className="hr-soft" />
          <h3>
            Shariah screening{" "}
            <span className={`badge ${VERDICT_BADGE[asmt.shariah.verdict]}`}>
              {asmt.shariah.verdict}
            </span>{" "}
            <Sim label="KEYWORD SCREEN — SIMULATED" />
          </h3>
          {asmt.shariah.findings.length === 0 ? (
            <p className="muted">No Riba, haram activity, Maysir, Gharar or structure issues found.</p>
          ) : (
            asmt.shariah.findings.map((f, i) => (
              <div className="finding" key={i}>
                <span
                  className={`badge ${f.level === "non_compliant" ? "b-noncompliant" : "b-review"}`}
                >
                  {f.category}
                </span>{" "}
                {f.detail}{" "}
                <span className="trigger">
                  — triggered by: <code>{f.trigger}</code>
                </span>
              </div>
            ))
          )}
          {asmt.shariah.suggestedAlternative ? (
            <div className="alert alert-warn">
              Smart substitution: the <b>activity</b> is permissible — the <b>structure</b> is the
              problem. Suggested compliant alternative:{" "}
              <b>{asmt.shariah.suggestedAlternative}</b>.
            </div>
          ) : null}
          {asmt.shariah.activityHaram ? (
            <div className="alert alert-danger">
              The underlying activity itself is non-permissible — no Islamic structure can make it
              compliant. No alternative is suggested.
            </div>
          ) : null}

          <hr className="hr-soft" />
          <h3>
            Advisory narrative <Sim label="TEMPLATE — SIMULATED LLM" />
          </h3>
          {asmt.narrativeEn ? (
            <>
              <div className="tabs">
                <button className={lang === "en" ? "active" : ""} onClick={() => setLang("en")}>
                  English
                </button>
                <button className={lang === "ms" ? "active" : ""} onClick={() => setLang("ms")}>
                  Bahasa Malaysia
                </button>
              </div>
              <p>{lang === "en" ? asmt.narrativeEn : asmt.narrativeMs}</p>
            </>
          ) : (
            <p className="muted">
              Narrative suppressed: the AI-input guard flagged this application&rsquo;s free text.
            </p>
          )}

          {a.status === "Pending" ? (
            <>
              <hr className="hr-soft" />
              <h3>Your decision</h3>
              <div className="field">
                <label>Decision note (recorded in the tamper-evident audit trail)</label>
                <textarea
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="Reasoning for the applicant and the auditor…"
                />
              </div>
              <div className="btn-row" style={{ marginTop: 10 }}>
                <button
                  className="btn btn-primary"
                  disabled={deciding || nonCompliant}
                  title={
                    nonCompliant
                      ? "Server will refuse (422): non-compliant structures cannot be approved."
                      : undefined
                  }
                  onClick={() => decide("Approved")}
                >
                  Approve
                </button>
                <select
                  value={alt}
                  onChange={(e) => setAlt(e.target.value as CompliantProduct)}
                  style={{ padding: ".45rem .6rem", borderRadius: 8, border: "1px solid var(--line)" }}
                >
                  {COMPLIANT_PRODUCTS.map((p) => (
                    <option key={p} value={p}>
                      {p}
                    </option>
                  ))}
                </select>
                <button className="btn btn-gold" disabled={deciding} onClick={() => decide("Alternative offered")}>
                  Offer alternative
                </button>
                <button className="btn btn-danger" disabled={deciding} onClick={() => decide("Declined")}>
                  Decline
                </button>
              </div>
              {nonCompliant ? (
                <p className="muted">
                  Approve is disabled here as a courtesy — and even a forged request is rejected
                  by the server with <code>422</code>.
                </p>
              ) : null}
            </>
          ) : a.decision ? (
            <>
              <hr className="hr-soft" />
              <h3>Decision</h3>
              <dl className="kv">
                <dt>Outcome</dt>
                <dd>
                  <span className={`badge ${STATUS_BADGE[a.status]}`}>{a.status}</span>
                  {a.decision.alternativeProduct ? ` → ${a.decision.alternativeProduct}` : ""}
                </dd>
                <dt>By</dt>
                <dd>{a.decision.byUsername}</dd>
                <dt>At</dt>
                <dd>{new Date(a.decision.at).toLocaleString()}</dd>
                <dt>Note</dt>
                <dd>{a.decision.note || "—"}</dd>
              </dl>
            </>
          ) : null}

          {msg ? <div className={`alert alert-${msg.kind}`}>{msg.text}</div> : null}
        </div>
      ) : (
        <IdentityPanel />
      )}
    </AppShell>
  );
}
