"use client";

import { useCallback, useEffect, useState } from "react";
import { useTideCloak } from "@tidecloak/nextjs";
import { AppShell } from "@/components/AppShell";
import { IdentityPanel } from "@/components/IdentityPanel";
import { Sim } from "@/components/Sim";
import { useApi } from "@/components/useApi";
import { VAULT_TAG } from "@/lib/config";
import { PRODUCTS, type Application, type VaultItem } from "@/lib/types";

const STATUS_BADGE: Record<string, string> = {
  Pending: "b-pending",
  Approved: "b-approved",
  "Alternative offered": "b-alt",
  Declined: "b-declined",
};

const EMPTY_FORM = {
  fullName: "",
  occupation: "",
  product: "Murabahah",
  purpose: "",
  amount: "8000",
  tenureMonths: "18",
  monthlyIncome: "3500",
  monthlyCommitments: "400",
  incomeHistoryMonths: "12",
  ewalletMonthlyInflow: "3000",
};

export default function ApplicantPage() {
  const api = useApi();
  const { doEncrypt, doDecrypt } = useTideCloak();

  /* ── my applications ── */
  const [apps, setApps] = useState<Application[]>([]);
  const loadApps = useCallback(async () => {
    const res = await api("/api/applications?scope=mine");
    if (res.ok) setApps(((await res.json()) as { applications: Application[] }).applications);
  }, [api]);

  /* ── application form ── */
  const [form, setForm] = useState<Record<string, string>>(EMPTY_FORM);
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [submitMsg, setSubmitMsg] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) =>
    setForm((f) => ({ ...f, [k]: e.target.value }));

  const submit = async () => {
    setSubmitting(true);
    setSubmitMsg(null);
    setFieldErrors({});
    try {
      const res = await api("/api/applications", {
        method: "POST",
        body: JSON.stringify({
          ...form,
          amount: Number(form.amount),
          tenureMonths: Number(form.tenureMonths),
          monthlyIncome: Number(form.monthlyIncome),
          monthlyCommitments: Number(form.monthlyCommitments),
          incomeHistoryMonths: Number(form.incomeHistoryMonths),
          ewalletMonthlyInflow: Number(form.ewalletMonthlyInflow),
        }),
      });
      const data = await res.json();
      if (res.status === 201) {
        setSubmitMsg(`Submitted as ${data.application.id}. An officer will review it.`);
        setForm((f) => ({ ...f, purpose: "" }));
        await loadApps();
      } else if (res.status === 400 && Array.isArray(data.fields)) {
        const fe: Record<string, string> = {};
        for (const f of data.fields as { field: string; message: string }[]) fe[f.field] = f.message;
        setFieldErrors(fe);
        setSubmitMsg("The server rejected some fields — fix them and resubmit.");
      } else {
        setSubmitMsg(String(data.error ?? `Error ${res.status}`));
      }
    } catch (e) {
      setSubmitMsg(e instanceof Error ? e.message : "Network error");
    } finally {
      setSubmitting(false);
    }
  };

  /* ── private vault ── */
  const [items, setItems] = useState<VaultItem[]>([]);
  const [vLabel, setVLabel] = useState("IC number");
  const [vSecret, setVSecret] = useState("");
  const [vBusy, setVBusy] = useState(false);
  const [vMsg, setVMsg] = useState<string | null>(null);
  const [plain, setPlain] = useState<Record<string, string>>({});

  const loadVault = useCallback(async () => {
    const res = await api("/api/vault");
    if (res.ok) setItems(((await res.json()) as { items: VaultItem[] }).items);
  }, [api]);

  const encryptAndStore = async () => {
    setVBusy(true);
    setVMsg(null);
    try {
      // Encrypt IN THE BROWSER with the user's own Tide-held keys ("vault" tag).
      const [ciphertext] = (await doEncrypt([{ data: vSecret, tags: [VAULT_TAG] }])) as string[];
      const res = await api("/api/vault", {
        method: "POST",
        body: JSON.stringify({ label: vLabel, ciphertext }),
      });
      const data = await res.json();
      if (res.status === 201) {
        setVSecret("");
        setVMsg("Stored. The server received ciphertext only.");
        await loadVault();
      } else {
        setVMsg(String(data.error ?? `Error ${res.status}`));
      }
    } catch (e) {
      setVMsg(
        (e instanceof Error ? e.message : "Encryption failed") +
          " — check you hold the _tide_vault.selfencrypt role."
      );
    } finally {
      setVBusy(false);
    }
  };

  const decryptItem = async (item: VaultItem) => {
    try {
      const [pt] = (await doDecrypt([{ encrypted: item.ciphertext, tags: [VAULT_TAG] }])) as unknown[];
      setPlain((p) => ({ ...p, [item.id]: String(pt) }));
    } catch (e) {
      setPlain((p) => ({
        ...p,
        [item.id]: `✗ decrypt failed: ${e instanceof Error ? e.message : "error"}`,
      }));
    }
  };

  const deleteItem = async (id: string) => {
    await api(`/api/vault?id=${encodeURIComponent(id)}`, { method: "DELETE" });
    setPlain((p) => {
      const { [id]: _drop, ...rest } = p;
      return rest;
    });
    await loadVault();
  };

  useEffect(() => {
    void loadApps();
    void loadVault();
  }, [loadApps, loadVault]);

  const num = (k: string, label: string, hint?: string) => (
    <div className="field" key={k}>
      <label>
        {label} {hint ? <span className="muted">({hint})</span> : null}
      </label>
      <input type="number" value={form[k]} onChange={set(k)} />
      {fieldErrors[k] ? <span className="err-text">{fieldErrors[k]}</span> : null}
    </div>
  );

  return (
    <AppShell
      active="/applicant"
      title="My applications"
      subtitle="Apply with your real income story — no payslips needed. Your private documents stay encrypted with keys only you hold."
    >
      <div className="grid2">
        <IdentityPanel />

        {/* ── New application ── */}
        <div className="card">
          <h3>
            New financing application <Sim label="SELF-DECLARED DATA — SIMULATED" />
          </h3>
          <p className="muted">
            In production, income and e-wallet figures come from open-banking / e-wallet APIs
            with your consent. For the demo you declare them yourself.
          </p>
          <div className="form-grid">
            <div className="field">
              <label>Full name</label>
              <input value={form.fullName} onChange={set("fullName")} placeholder="e.g. Aisyah binti Rahman" />
              {fieldErrors.fullName ? <span className="err-text">{fieldErrors.fullName}</span> : null}
            </div>
            <div className="field">
              <label>Occupation</label>
              <input value={form.occupation} onChange={set("occupation")} placeholder="e.g. E-hailing driver" />
              {fieldErrors.occupation ? <span className="err-text">{fieldErrors.occupation}</span> : null}
            </div>
            <div className="field">
              <label>Financing structure</label>
              <select value={form.product} onChange={set("product")}>
                {PRODUCTS.map((p) => (
                  <option key={p} value={p}>
                    {p}
                    {p === "Conventional loan" ? " (non-compliant — for demo)" : ""}
                  </option>
                ))}
              </select>
            </div>
            {num("amount", "Amount (RM)")}
            {num("tenureMonths", "Tenure (months)")}
            {num("monthlyIncome", "Monthly income (RM)")}
            {num("monthlyCommitments", "Monthly commitments (RM)")}
            {num("incomeHistoryMonths", "Income history (months)", "on gig platforms")}
            {num("ewalletMonthlyInflow", "E-wallet inflow (RM/month)")}
            <div className="field span2">
              <label>Purpose of financing</label>
              <textarea
                value={form.purpose}
                onChange={set("purpose")}
                placeholder="What exactly will the funds be used for?"
              />
              {fieldErrors.purpose ? <span className="err-text">{fieldErrors.purpose}</span> : null}
            </div>
          </div>
          <div className="btn-row" style={{ marginTop: 10 }}>
            <button className="btn btn-primary" onClick={submit} disabled={submitting}>
              {submitting ? "Submitting…" : "Submit application"}
            </button>
            {submitMsg ? <span className="muted">{submitMsg}</span> : null}
          </div>
        </div>
      </div>

      {/* ── My applications ── */}
      <div className="card">
        <h3>My applications</h3>
        {apps.length === 0 ? (
          <p className="muted">No applications yet — submit your first one above.</p>
        ) : (
          <table className="tbl">
            <thead>
              <tr>
                <th>Ref</th>
                <th>Structure</th>
                <th>Amount</th>
                <th>Submitted</th>
                <th>Status</th>
                <th>Officer note</th>
              </tr>
            </thead>
            <tbody>
              {apps.map((a) => (
                <tr key={a.id}>
                  <td className="mono">{a.id}</td>
                  <td>
                    {a.input.product}
                    {a.decision?.alternativeProduct ? (
                      <div className="muted">→ offered: {a.decision.alternativeProduct}</div>
                    ) : null}
                  </td>
                  <td>RM{a.input.amount.toLocaleString()}</td>
                  <td>{new Date(a.createdAt).toLocaleDateString()}</td>
                  <td>
                    <span className={`badge ${STATUS_BADGE[a.status]}`}>{a.status}</span>
                  </td>
                  <td className="muted">{a.decision?.note || "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* ── Private vault ── */}
      <div className="card">
        <h3>Private vault — encrypted in your browser</h3>
        <p className="muted">
          Documents here are encrypted with <code>doEncrypt</code> using keys held by{" "}
          <b>your Tide account</b> (tag <code>{VAULT_TAG}</code>) before they ever leave this
          page. BAYAN&rsquo;s server — and any attacker who steals its database, and any admin —
          stores and sees <b>ciphertext only</b>. This encryption is real, not simulated.
        </p>
        <div className="form-grid">
          <div className="field">
            <label>Label</label>
            <input value={vLabel} onChange={(e) => setVLabel(e.target.value)} />
          </div>
          <div className="field">
            <label>Secret value (e.g. IC number, bank account)</label>
            <input
              value={vSecret}
              onChange={(e) => setVSecret(e.target.value)}
              placeholder="Never sent in plaintext"
            />
          </div>
        </div>
        <div className="btn-row" style={{ marginTop: 10 }}>
          <button
            className="btn btn-primary"
            onClick={encryptAndStore}
            disabled={vBusy || !vSecret}
          >
            {vBusy ? "Encrypting…" : "Encrypt in browser & store"}
          </button>
          {vMsg ? <span className="muted">{vMsg}</span> : null}
        </div>

        {items.length > 0 ? <hr className="hr-soft" /> : null}
        {items.map((item) => (
          <div key={item.id} style={{ marginBottom: 14 }}>
            <div className="btn-row">
              <b>{item.label}</b>
              <span className="muted">{new Date(item.createdAt).toLocaleString()}</span>
              <button className="btn btn-sm" onClick={() => decryptItem(item)}>
                Decrypt (in browser)
              </button>
              <button className="btn btn-sm btn-ghost" onClick={() => deleteItem(item.id)}>
                Delete
              </button>
            </div>
            <div className="muted" style={{ margin: "4px 0 2px" }}>
              What the server sees:
            </div>
            <div className="cipher-box">{item.ciphertext}</div>
            {plain[item.id] !== undefined ? (
              <div className="plain-box" style={{ marginTop: 6 }}>
                Decrypted (only you can do this): <b>{plain[item.id]}</b>
              </div>
            ) : null}
          </div>
        ))}
      </div>
    </AppShell>
  );
}
