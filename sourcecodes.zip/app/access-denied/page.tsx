"use client";

import Link from "next/link";
import { Suspense } from "react";
import { useSearchParams } from "next/navigation";
import { useTideCloak } from "@tidecloak/nextjs";
import { ROLES } from "@/lib/config";

function AccessDeniedInner() {
  const params = useSearchParams();
  const from = params.get("from") ?? "that page";
  const { hasRealmRole, authenticated } = useTideCloak();

  const home = !authenticated
    ? "/"
    : hasRealmRole(ROLES.officer)
      ? "/officer"
      : hasRealmRole(ROLES.auditor)
        ? "/auditor"
        : "/applicant";

  return (
    <div className="center-screen">
      <div className="setup-card">
        <h2>Access denied — checked on the server</h2>
        <p>
          Your Tide-verified token does not carry the realm role required for{" "}
          <code>{from}</code>. This was enforced by BAYAN&rsquo;s server-side proxy{" "}
          <em>before the page rendered</em> — hiding a link or editing the browser cannot get
          around it, and every API behind the page re-verifies the token again.
        </p>
        <p className="muted">
          How roles are granted: an administrator assigns <code>officer</code> or{" "}
          <code>auditor</code> in the TideCloak console, and the change only takes effect once
          the pending change-request is <b>approved under IGA quorum governance</b>. One phished
          or rogue admin cannot quietly grant themselves — or anyone — a role.
        </p>
        <div className="btn-row">
          <Link className="btn btn-primary" href={home}>
            Go to my workspace
          </Link>
          <Link className="btn" href="/">
            Landing page
          </Link>
        </div>
      </div>
    </div>
  );
}

export default function AccessDeniedPage() {
  return (
    <Suspense
      fallback={
        <div className="center-screen">
          <p className="muted">Loading…</p>
        </div>
      }
    >
      <AccessDeniedInner />
    </Suspense>
  );
}
