"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useTideCloak } from "@tidecloak/nextjs";

const PILLARS = [
  {
    t: "Alternative-data scoring",
    d: "Income history, e-wallet inflow and commitments replace payslips for B40 and gig workers.",
  },
  {
    t: "Shariah-first by design",
    d: "Riba, haram activity, maysir and gharar are screened — non-compliant structures cannot be approved, only substituted.",
  },
  {
    t: "Zero blind trust",
    d: "Tide-secured login, server-verified roles, browser-side vault encryption, quorum-governed admin — no single key to steal.",
  },
  {
    t: "Tamper-evident audit",
    d: "Every event is SHA-256-chained to the last. Edit one row and the auditor sees exactly where the chain broke.",
  },
];

export default function LandingPage() {
  const { login, authenticated, isInitializing } = useTideCloak();
  const router = useRouter();

  useEffect(() => {
    if (!isInitializing && authenticated) router.replace("/auth/redirect");
  }, [authenticated, isInitializing, router]);

  return (
    <div className="landing">
      <div className="hero">
        <h1>
          BAYAN <span className="ar">بَيَان</span>
        </h1>
        <p>
          Shariah-compliant micro-financing for Malaysia&rsquo;s e-hailing drivers, riders and
          home sellers — people with real income but no payslips. Assessing them means collecting
          their most sensitive data, so BAYAN is built on one assumption: <b>we will be breached,
          and it must not matter.</b>
        </p>
        <button className="btn btn-primary" onClick={() => login()} disabled={isInitializing}>
          {isInitializing ? "Connecting…" : "Sign in with Tide"}
        </button>
        <div className="muted" style={{ marginTop: 8 }}>
          No passwords are stored by BAYAN — authentication is decentralised via TideCloak.
        </div>
      </div>

      <div className="pillars">
        {PILLARS.map((p) => (
          <div key={p.t} className="pillar">
            <h4>{p.t}</h4>
            <p>{p.d}</p>
          </div>
        ))}
      </div>

      <div className="landing-footer">
        RMIT Hackathon 2026 · Challenge 2 — Build Without Blind Trust · prototype with clearly
        marked SIMULATED components
      </div>
    </div>
  );
}
