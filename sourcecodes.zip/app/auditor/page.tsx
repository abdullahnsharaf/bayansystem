"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { AppShell } from "@/components/AppShell";
import { IdentityPanel } from "@/components/IdentityPanel";
import { Sim } from "@/components/Sim";
import { useApi } from "@/components/useApi";
import type { AuditEntry } from "@/lib/types";

type Chain = { ok: true } | { ok: false; brokenAt: number };

function download(filename: string, mime: string, content: string) {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
}

function toCsv(entries: AuditEntry[]): string {
  const esc = (v: unknown) => `"${String(v).replace(/"/g, '""')}"`;
  const head = ["seq", "ts", "actor", "actorUsername", "role", "action", "target", "details", "prevHash", "hash"];
  const rows = entries.map((e) =>
    [e.seq, e.ts, e.actor, e.actorUsername, e.role, e.action, e.target, JSON.stringify(e.details), e.prevHash, e.hash]
      .map(esc)
      .join(",")
  );
  return [head.join(","), ...rows].join("\n");
}

export default function AuditorPage() {
  const api = useApi();
  const [entries, setEntries] = useState<AuditEntry[]>([]);
  const [chain, setChain] = useState<Chain | null>(null);
  const [q, setQ] = useState("");
  const [msg, setMsg] = useState<string | null>(null);

  const load = useCallback(async () => {
    const res = await api("/api/audit");
    if (res.ok) {
      const data = (await res.json()) as { entries: AuditEntry[]; chain: Chain };
      setEntries(data.entries);
      setChain(data.chain);
    } else {
      setMsg(`GET /api/audit → ${res.status}`);
    }
  }, [api]);

  useEffect(() => {
    void load();
  }, [load]);

  const filtered = useMemo(() => {
    const needle = q.trim().toLowerCase();
    if (!needle) return entries;
    return entries.filter((e) =>
      [e.actorUsername, e.actor, e.action, e.target, JSON.stringify(e.details)]
        .join(" ")
        .toLowerCase()
        .includes(needle)
    );
  }, [entries, q]);

  const exportRegister = async () => {
    setMsg(null);
    const res = await api("/api/applications", { method: "PUT" });
    const data = await res.json();
    if (res.ok) {
      download(`bayan-register-${Date.now()}.json`, "application/json", JSON.stringify(data, null, 2));
      setMsg("Register exported — and the export itself was written to the audit chain.");
      await load();
    } else {
      setMsg(String(data.error ?? `Error ${res.status}`));
    }
  };

  return (
    <AppShell
      active="/auditor"
      title="Audit trail"
      subtitle="Read-only. Every event is SHA-256-chained to the previous one — the chain is re-verified on every load."
    >
      {chain ? (
        chain.ok ? (
          <div className="integrity-banner integrity-ok">
            ✓ Chain intact — {entries.length} events verified, none modified or removed.
          </div>
        ) : (
          <div className="integrity-banner integrity-bad">
            ✗ CHAIN BROKEN at event #{chain.brokenAt} — this entry (or one before it) was
            tampered with after being written.
          </div>
        )
      ) : null}

      <div className="card">
        <div className="toolbar">
          <input
            className="search-input"
            placeholder="Search actor, action, target, details…"
            value={q}
            onChange={(e) => setQ(e.target.value)}
          />
          <button className="btn" onClick={() => download(`bayan-audit-${Date.now()}.csv`, "text/csv", toCsv(filtered))}>
            Export CSV ({filtered.length})
          </button>
          <button className="btn btn-primary" onClick={exportRegister}>
            Export full register (audited)
          </button>
          <button className="btn btn-ghost" onClick={load}>
            Re-verify chain
          </button>
        </div>
        {msg ? <div className="alert alert-warn">{msg}</div> : null}

        <table className="tbl">
          <thead>
            <tr>
              <th>#</th>
              <th>Time</th>
              <th>Actor</th>
              <th>Role</th>
              <th>Action</th>
              <th>Target</th>
              <th>Details</th>
              <th>Hash</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((e) => (
              <tr key={e.seq}>
                <td className="mono">{e.seq}</td>
                <td className="mono">{new Date(e.ts).toLocaleString()}</td>
                <td>{e.actorUsername}</td>
                <td>
                  <span className="badge b-pending">{e.role}</span>
                </td>
                <td>
                  <b style={e.action.includes("BLOCKED") ? { color: "var(--red)" } : undefined}>
                    {e.action}
                  </b>
                </td>
                <td className="mono">{e.target}</td>
                <td className="muted">{JSON.stringify(e.details)}</td>
                <td className="mono" title={`prev: ${e.prevHash}`}>
                  {e.hash.slice(0, 12)}…
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <p className="muted" style={{ marginBottom: 0 }}>
          Chain hashing is real SHA-256; the store behind it is a JSON file{" "}
          <Sim label="FILE STORE — SIMULATED" /> (production: Postgres + write-once anchoring).
          Try it: edit any audit row in <code>.data/bayan.json</code> (or run{" "}
          <code>npm run tamper</code>) and reload — the banner turns red at the exact event.
        </p>
      </div>

      <IdentityPanel />
    </AppShell>
  );
}
