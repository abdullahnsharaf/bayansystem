"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useTideCloak } from "@tidecloak/nextjs";
import { ROLES } from "@/lib/config";

/** Post-login router: sends each user to the workspace their TideCloak realm
 *  role entitles them to (officer → /officer, auditor → /auditor, else
 *  /applicant — every new user holds `applicant` by default). */
export default function RedirectPage() {
  const { authenticated, isInitializing, logout, hasRealmRole } = useTideCloak();
  const router = useRouter();
  const [message, setMessage] = useState("Completing sign-in with Tide…");

  // Middleware/proxy signals token expiry with ?auth=failed — sign out cleanly.
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get("auth") === "failed") {
      setMessage("Session expired — signing you out…");
      sessionStorage.setItem("tokenExpired", "true");
      logout();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (isInitializing) return;
    if (!authenticated) {
      router.replace("/");
      return;
    }
    if (hasRealmRole(ROLES.officer)) router.replace("/officer");
    else if (hasRealmRole(ROLES.auditor)) router.replace("/auditor");
    else router.replace("/applicant");
  }, [authenticated, isInitializing, hasRealmRole, router]);

  return (
    <div className="center-screen">
      <p className="muted">{message}</p>
    </div>
  );
}
