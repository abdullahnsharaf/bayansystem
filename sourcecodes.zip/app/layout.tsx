import type { Metadata } from "next";
import type { ReactNode } from "react";
import { TideCloakProvider } from "@tidecloak/nextjs";
import rawConfig from "../tidecloak.json";
import "./globals.css";

const tcConfig = rawConfig as Record<string, unknown>;
const isConfigured =
  typeof tcConfig["auth-server-url"] === "string" && typeof tcConfig["realm"] === "string";

export const metadata: Metadata = {
  title: "BAYAN — Shariah-first micro-financing",
  description:
    "Shariah-compliant micro-financing for Malaysia's gig economy, built on TideCloak so no single party has complete control. RMIT Hackathon 2026 prototype.",
};

function SetupScreen() {
  return (
    <div className="center-screen">
      <div className="setup-card">
        <h2>Connect BAYAN to TideCloak</h2>
        <p className="muted">
          <code>tidecloak.json</code> is empty — the realm has not been provisioned yet. BAYAN
          refuses to run without its trust layer.
        </p>
        <ol>
          <li>
            Start TideCloak:
            <pre>{`docker run -d --name tidecloak \\
  -p 8080:8080 \\
  -e KC_BOOTSTRAP_ADMIN_USERNAME=admin \\
  -e KC_BOOTSTRAP_ADMIN_PASSWORD=password \\
  tideorg/tidecloak-dev:latest`}</pre>
          </li>
          <li>
            Provision the <code>bayan</code> realm (roles, client, IGA, Tide IdP) and write the
            adapter config:
            <pre>npm run init</pre>
          </li>
          <li>
            Restart the dev server, then reload this page:
            <pre>npm run dev</pre>
          </li>
        </ol>
        <p className="muted">
          Full setup, demo users and troubleshooting (including Windows) are in the README.
        </p>
      </div>
    </div>
  );
}

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>
        <div className="proto-banner">
          PROTOTYPE — RMIT Hackathon 2026 · demo data · anything marked <b>SIMULATED</b> is
          mocked (see README)
        </div>
        {isConfigured ? (
          <TideCloakProvider config={tcConfig}>{children}</TideCloakProvider>
        ) : (
          <SetupScreen />
        )}
      </body>
    </html>
  );
}
