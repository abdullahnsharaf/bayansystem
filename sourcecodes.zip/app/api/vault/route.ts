import { NextRequest, NextResponse } from "next/server";
import { requireRole } from "@/lib/server/auth";
import { ROLES } from "@/lib/config";
import { addVaultItem, deleteVaultItem, getVault } from "@/lib/server/db";

/** The vault stores Tide CIPHERTEXT only. This shape check is a guard rail
 *  (base64url-ish, no whitespace, not JSON) — the real guarantee is that
 *  encryption happens in the browser with the user's Tide-held keys, so the
 *  server never receives plaintext in the first place. */
function looksLikeCiphertext(s: string): boolean {
  if (s.length < 16 || s.length > 20000) return false;
  if (/\s/.test(s)) return false;
  if (!/^[A-Za-z0-9+/=_.:-]+$/.test(s)) return false;
  const first = s[0];
  if (first === "{" || first === "[") return false;
  return true;
}

/** GET /api/vault — the caller's own items only (keyed by token sub). */
export async function GET(req: NextRequest): Promise<NextResponse> {
  const auth = await requireRole(req, [ROLES.applicant]);
  if (auth.error) return auth.error;
  return NextResponse.json({ items: getVault(auth.caller.sub) });
}

/** POST /api/vault — { label, ciphertext }; anything but ciphertext is rejected. */
export async function POST(req: NextRequest): Promise<NextResponse> {
  const auth = await requireRole(req, [ROLES.applicant]);
  if (auth.error) return auth.error;

  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return NextResponse.json({ error: "Invalid JSON body." }, { status: 400 });
  }

  const label = typeof body.label === "string" ? body.label.trim() : "";
  if (label.length < 1 || label.length > 60) {
    return NextResponse.json({ error: "label must be 1–60 characters." }, { status: 400 });
  }

  const ciphertext = typeof body.ciphertext === "string" ? body.ciphertext : "";
  if (!looksLikeCiphertext(ciphertext)) {
    return NextResponse.json(
      { error: "Rejected: the vault accepts Tide ciphertext strings only — never plaintext." },
      { status: 400 }
    );
  }

  const item = addVaultItem(auth.caller, label, ciphertext);
  return NextResponse.json({ item }, { status: 201 });
}

/** DELETE /api/vault?id=… — own items only. */
export async function DELETE(req: NextRequest): Promise<NextResponse> {
  const auth = await requireRole(req, [ROLES.applicant]);
  if (auth.error) return auth.error;

  const id = req.nextUrl.searchParams.get("id") ?? "";
  if (!id) return NextResponse.json({ error: "id query parameter required." }, { status: 400 });

  const removed = deleteVaultItem(auth.caller, id);
  if (!removed) return NextResponse.json({ error: "Item not found." }, { status: 404 });
  return NextResponse.json({ ok: true });
}
