import { NextRequest, NextResponse } from "next/server";
import { requireRole } from "@/lib/server/auth";
import { ROLES } from "@/lib/config";

/** Server-verified identity for the IdentityPanel — proof that role checks
 *  happen on the server against the token, not in the browser. */
export async function GET(req: NextRequest): Promise<NextResponse> {
  const auth = await requireRole(req, [ROLES.applicant, ROLES.officer, ROLES.auditor]);
  if (auth.error) return auth.error;
  const { caller } = auth;
  return NextResponse.json({
    serverVerified: true,
    checkedAt: new Date().toISOString(),
    sub: caller.sub,
    username: caller.username,
    vuid: caller.vuid,
    roles: caller.roles,
  });
}
