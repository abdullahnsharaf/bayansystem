import { NextRequest, NextResponse } from "next/server";
import { requireRole } from "@/lib/server/auth";
import { ROLES } from "@/lib/config";
import { getAudit } from "@/lib/server/db";

/** GET /api/audit — auditor (and officer, read-only): entries + chain verdict.
 *  The SHA-256 chain is re-verified on EVERY read, so any tampering with the
 *  store surfaces immediately as `chain.ok = false` with the broken seq. */
export async function GET(req: NextRequest): Promise<NextResponse> {
  const auth = await requireRole(req, [ROLES.auditor, ROLES.officer]);
  if (auth.error) return auth.error;

  const { entries, chain } = getAudit();
  return NextResponse.json({ entries, chain });
}
