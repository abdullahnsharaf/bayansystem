import { NextRequest, NextResponse } from "next/server";
import { requireRole } from "@/lib/server/auth";
import { ROLES } from "@/lib/config";
import { decideApplication } from "@/lib/server/db";
import type { CompliantProduct, DecisionAction } from "@/lib/types";
import { COMPLIANT_PRODUCTS } from "@/lib/types";

const ACTIONS: DecisionAction[] = ["Approved", "Alternative offered", "Declined"];

/**
 * POST /api/applications/[id]/decision — officer only.
 *   404 unknown id · 403 + BLOCKED audit entry on self-decision (SoD)
 *   409 already decided · 422 approving a Shariah non-compliant structure
 *   400 bad action / missing compliant alternative
 */
export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
): Promise<NextResponse> {
  const auth = await requireRole(req, [ROLES.officer]);
  if (auth.error) return auth.error;
  const { caller } = auth;
  const { id } = await params;

  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return NextResponse.json({ error: "Invalid JSON body." }, { status: 400 });
  }

  const action = ACTIONS.find((a) => a === body.action);
  if (!action) {
    return NextResponse.json(
      { error: `action must be one of: ${ACTIONS.join(" | ")}.` },
      { status: 400 }
    );
  }

  const noteRaw = typeof body.note === "string" ? body.note.trim() : "";
  if (noteRaw.length > 500) {
    return NextResponse.json({ error: "note must be ≤ 500 characters." }, { status: 400 });
  }

  const altRaw = typeof body.alternativeProduct === "string" ? body.alternativeProduct : undefined;
  const alternativeProduct = COMPLIANT_PRODUCTS.find((p) => p === altRaw) as
    | CompliantProduct
    | undefined;

  const result = decideApplication(caller, id, action, noteRaw, alternativeProduct);
  if (!result.ok) {
    return NextResponse.json({ error: result.error }, { status: result.status });
  }
  return NextResponse.json({ application: result.app });
}
