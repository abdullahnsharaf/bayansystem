import { NextRequest, NextResponse } from "next/server";
import { requireRole } from "@/lib/server/auth";
import { ROLES } from "@/lib/config";
import { validateApplicationInput } from "@/lib/validate";
import { createApplication, exportRegister, listApplications } from "@/lib/server/db";

/**
 * GET /api/applications
 *   officer / auditor → full register (or ?scope=mine for their own files)
 *   applicant          → ONLY their own applications, enforced by token sub
 */
export async function GET(req: NextRequest): Promise<NextResponse> {
  const auth = await requireRole(req, [ROLES.applicant, ROLES.officer, ROLES.auditor]);
  if (auth.error) return auth.error;
  const { caller } = auth;

  const scope = req.nextUrl.searchParams.get("scope");
  const mayViewAll =
    caller.roles.includes(ROLES.officer) || caller.roles.includes(ROLES.auditor);

  const apps =
    mayViewAll && scope !== "mine" ? listApplications() : listApplications(caller.sub);

  return NextResponse.json({ applications: apps });
}

/** POST /api/applications — applicant submits; every field validated server-side. */
export async function POST(req: NextRequest): Promise<NextResponse> {
  const auth = await requireRole(req, [ROLES.applicant]);
  if (auth.error) return auth.error;
  const { caller } = auth;

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body." }, { status: 400 });
  }

  const result = validateApplicationInput(body);
  if (!result.ok) {
    return NextResponse.json(
      { error: "Validation failed.", fields: result.fields },
      { status: 400 }
    );
  }

  const app = createApplication(caller, result.value);
  return NextResponse.json({ application: app }, { status: 201 });
}

/** PUT /api/applications — auditor-only full register export (the export
 *  itself is written to the audit chain). */
export async function PUT(req: NextRequest): Promise<NextResponse> {
  const auth = await requireRole(req, [ROLES.auditor]);
  if (auth.error) return auth.error;

  const register = exportRegister(auth.caller);
  return NextResponse.json(register);
}
