/**
 * BAYAN assessment engine — SIMULATED, transparent, deterministic rules.
 *
 * Everything here is explainable on purpose: each score adjustment is returned
 * as a factor with its points and a human note, every Shariah finding carries
 * the exact trigger text, and the injection guard lists the pattern it matched.
 *
 * SIMULATED components (see README): the scoring rules (production: XGBoost +
 * SHAP), the keyword Shariah screen (production: fatwa-grounded RAG engine),
 * the keyword injection guard (production: the Challenge-1 fine-tuned XLM-R
 * classifier served as an API), and the template narrative (production: LLM
 * with the injection guard in front of it).
 */
import type {
  ApplicationInput,
  Assessment,
  CompliantProduct,
  InjectionMatch,
  InjectionResult,
  Recommendation,
  RiskBand,
  ScoreFactor,
  ShariahFinding,
  ShariahResult,
  ShariahVerdict,
} from "./types";

export const ENGINE_VERSION = "bayan-rules-1.0 (SIMULATED)";

/** Flat profit rate used for the instalment estimate (SIMULATED pricing). */
export const PROFIT_RATE_PA = 0.065;

const r2 = (n: number) => Math.round(n * 100) / 100;

/* ────────────────────────────── Credit score ────────────────────────────── */

export function estimateInstalment(amount: number, tenureMonths: number): number {
  return r2((amount * (1 + PROFIT_RATE_PA * (tenureMonths / 12))) / tenureMonths);
}

function creditFactors(input: ApplicationInput, instalment: number, dsr: number) {
  const factors: ScoreFactor[] = [];
  const add = (label: string, points: number, note: string) =>
    factors.push({ label, points, note });

  // 1) Debt service ratio
  if (dsr <= 0.3)
    add("Debt service ratio", +80, `DSR ${(dsr * 100).toFixed(1)}% — healthy headroom after the new instalment.`);
  else if (dsr <= 0.45)
    add("Debt service ratio", +30, `DSR ${(dsr * 100).toFixed(1)}% — manageable.`);
  else if (dsr <= 0.6)
    add("Debt service ratio", -40, `DSR ${(dsr * 100).toFixed(1)}% — stretched.`);
  else if (dsr <= 0.7)
    add("Debt service ratio", -90, `DSR ${(dsr * 100).toFixed(1)}% — heavy burden.`);
  else
    add("Debt service ratio", -150, `DSR ${(dsr * 100).toFixed(1)}% — above the 70% hard ceiling.`);

  // 2) Income history (gig-platform continuity instead of payslips)
  const h = input.incomeHistoryMonths;
  if (h >= 12) add("Income history", +40, `${h} months of continuous platform income — stable track record.`);
  else if (h >= 6) add("Income history", +15, `${h} months of income history — building a track record.`);
  else add("Income history", -30, `Only ${h} months of income history — limited evidence.`);

  // 3) E-wallet inflow corroboration of declared income
  const ratio = input.monthlyIncome > 0 ? input.ewalletMonthlyInflow / input.monthlyIncome : 0;
  if (ratio >= 0.9)
    add("E-wallet corroboration", +50, `E-wallet inflow is ${(ratio * 100).toFixed(0)}% of declared income — strongly corroborates it.`);
  else if (ratio >= 0.6)
    add("E-wallet corroboration", +20, `E-wallet inflow covers ${(ratio * 100).toFixed(0)}% of declared income.`);
  else if (ratio >= 0.3)
    add("E-wallet corroboration", -10, `E-wallet inflow only covers ${(ratio * 100).toFixed(0)}% of declared income.`);
  else
    add("E-wallet corroboration", -40, `Declared income is barely visible in e-wallet inflow (${(ratio * 100).toFixed(0)}%).`);

  // 4) Amount requested vs annual income
  const multiple = input.monthlyIncome > 0 ? input.amount / (input.monthlyIncome * 12) : 99;
  if (multiple <= 0.5)
    add("Amount vs income", +20, `Request is ${(multiple * 100).toFixed(0)}% of annual income — modest.`);
  else if (multiple <= 1)
    add("Amount vs income", 0, `Request is ${(multiple * 100).toFixed(0)}% of annual income.`);
  else if (multiple <= 2)
    add("Amount vs income", -30, `Request is ${multiple.toFixed(1)}× annual income — large.`);
  else
    add("Amount vs income", -60, `Request is ${multiple.toFixed(1)}× annual income — very large.`);

  return factors;
}

/* ────────────────────────────── Shariah screen ──────────────────────────── */
/* Word-boundary regexes on purpose: "card" must not match inside "cardigan",
 * "interest" must not match "interested", and "interest-free" is not Riba.   */

const RE = {
  interest: /\binterest\b(?!\s*-?\s*free)/i,
  riba: /\briba\b/i,
  conventional: /\bconventional\s+(loan|financing|credit)\b/i,
  creditCard: /\bcredit\s?cards?\b/i,
  refinance: /\brefinanc\w*\b|\bconsolidat\w*\b|\bsettle\b|\bpay\s?off\b/i,
  haram:
    /\b(alcohol|liquor|arak|beer|wine|whisky|vodka|gambl\w*|judi|casino|bets?|betting|lottery|4d|toto|pork|babi|swine|tobacco|cigarettes?|rokok|vape|shisha|nightclub)\b/i,
  maysir:
    /\b(forex|fx\s?trading|crypto(currency|currencies)?|bitcoin|ethereum|day[-\s]?trad\w*|binary\s options|margin\s trading|leveraged?\s trading|speculat\w*)\b/i,
  vague: /\b(anything|whatever|misc(ellaneous)?|lain-?lain|urgent cash only)\b/i,
  leasableAsset:
    /\b(vehicles?|vans?|cars?|kereta|lorry|lorries|trucks?|motor(cycles?|bikes?|sikal)?|bikes?|machin(e|es|ery)|equipment|mesin|ovens?|freezers?|fridges?|printers?|laptops?|computers?|premises?|shoplots?|kiosks?|stalls?|property)\b/i,
  goods:
    /\b(stocks?|inventory|goods|ingredients?|bahan|materials?|supplies|ovens?|equipment|machin(e|es|ery)|phones?|laptops?|furniture|appliances?)\b/i,
};

function suggestAlternative(input: ApplicationInput): CompliantProduct {
  const text = `${input.purpose} ${input.occupation}`;
  if (RE.leasableAsset.test(text)) return "Ijarah"; // use of an asset
  if (RE.goods.test(text)) return "Murabahah"; // purchase of goods
  return "Tawarruq"; // cash need
}

export function screenShariah(input: ApplicationInput): ShariahResult {
  const findings: ShariahFinding[] = [];
  const text = `${input.purpose} ${input.occupation}`;
  const grab = (re: RegExp) => (text.match(re)?.[0] ?? "").slice(0, 60);

  // Riba — structure-level
  if (input.product === "Conventional loan") {
    findings.push({
      category: "Riba",
      level: "non_compliant",
      detail: "Conventional interest-bearing loan structure.",
      trigger: `product = "Conventional loan"`,
    });
  }
  if (RE.interest.test(text) || RE.riba.test(text) || RE.conventional.test(text)) {
    findings.push({
      category: "Riba",
      level: "non_compliant",
      detail: "Purpose references interest-bearing finance.",
      trigger: grab(RE.interest) || grab(RE.riba) || grab(RE.conventional),
    });
  } else if (RE.creditCard.test(text) && RE.refinance.test(text)) {
    findings.push({
      category: "Riba",
      level: "non_compliant",
      detail: "Refinancing an interest-bearing credit-card balance.",
      trigger: `${grab(RE.creditCard)} + ${grab(RE.refinance)}`,
    });
  }

  // Haram activity — activity-level, cannot be structured around
  if (RE.haram.test(text)) {
    findings.push({
      category: "Haram activity",
      level: "non_compliant",
      detail: "Financing a prohibited activity or product.",
      trigger: grab(RE.haram),
    });
  }

  // Maysir — speculation / gambling-like trading
  if (RE.maysir.test(text)) {
    findings.push({
      category: "Maysir",
      level: "non_compliant",
      detail: "Speculative trading — excessive uncertainty and gambling-like risk.",
      trigger: grab(RE.maysir),
    });
  }

  // Gharar — unclear use of funds
  if (input.purpose.trim().length < 12 || RE.vague.test(text)) {
    findings.push({
      category: "Gharar",
      level: "review",
      detail: "Use of funds is unclear — ask the applicant to specify.",
      trigger: input.purpose.trim().length < 12 ? "purpose too short" : grab(RE.vague),
    });
  }

  // Structure fit — Ijarah needs an identifiable leasable asset
  if (input.product === "Ijarah" && !RE.leasableAsset.test(text)) {
    findings.push({
      category: "Structure",
      level: "review",
      detail: "Ijarah (lease) selected but no identifiable leasable asset in the purpose.",
      trigger: `product = "Ijarah", no asset keyword found`,
    });
  }

  const activityHaram = findings.some(
    (f) => (f.category === "Haram activity" || f.category === "Maysir") && f.level === "non_compliant"
  );
  const structureNonCompliant =
    !activityHaram && findings.some((f) => f.category === "Riba" && f.level === "non_compliant");

  const verdict: ShariahVerdict = findings.some((f) => f.level === "non_compliant")
    ? "Non-compliant"
    : findings.length > 0
      ? "Needs review"
      : "Compliant";

  // Smart substitution: only when the STRUCTURE is the problem (or Ijarah
  // mis-fit). A haram ACTIVITY cannot be fixed by a different contract.
  let suggestedAlternative: CompliantProduct | null = null;
  if (!activityHaram) {
    if (structureNonCompliant) suggestedAlternative = suggestAlternative(input);
    else if (findings.some((f) => f.category === "Structure")) {
      const alt = suggestAlternative(input);
      suggestedAlternative = alt === "Ijarah" ? "Tawarruq" : alt;
    }
  }

  return { verdict, findings, activityHaram, structureNonCompliant, suggestedAlternative };
}

/* ──────────────────── AI-input guard (prompt injection) ─────────────────── */
/* Applicant free text is destined for an AI narrative/scoring pipeline, so it
 * is screened for instruction-hijack patterns in EN, MS, PT, FR and IT —
 * mirroring Challenge 1's multilingual prompt-attack classes.               */

interface GuardPattern {
  language: string;
  label: string;
  re: RegExp;
}

const GUARD_PATTERNS: GuardPattern[] = [
  // English
  { language: "EN", label: "instruction override", re: /\bignore\s+(all\s+|any\s+)?(previous|prior|above|earlier)\s+(instructions?|prompts?|rules?)\b/i },
  { language: "EN", label: "instruction override", re: /\bdisregard\s+(the\s+)?(instructions?|rules?|guidelines?|system)\b/i },
  { language: "EN", label: "system-prompt probe", re: /\bsystem\s+prompt\b/i },
  { language: "EN", label: "role manipulation", re: /\byou\s+are\s+now\b/i },
  { language: "EN", label: "role manipulation", re: /\bact\s+as\s+(an?\s+)?(admin(istrator)?|system|officer|developer)\b/i },
  { language: "EN", label: "auto-approve", re: /\bauto[-\s]?approve\b/i },
  { language: "EN", label: "auto-approve", re: /\bapprove\s+(this|my)\s+(application|loan|financing)\s+automatically\b/i },
  { language: "EN", label: "guard bypass", re: /\b(jailbreak|developer\s+mode)\b/i },
  { language: "EN", label: "guard bypass", re: /\boverride\s+(the\s+)?(rules?|checks?|system|screening)\b/i },
  // Bahasa Malaysia
  { language: "MS", label: "instruction override", re: /\babaikan\s+(semua\s+)?(arahan|peraturan)\b/i },
  { language: "MS", label: "instruction override", re: /\blupakan\s+arahan\b/i },
  { language: "MS", label: "auto-approve", re: /\blulus(kan)?\s+(secara\s+)?automatik\b/i },
  { language: "MS", label: "role manipulation", re: /\banda\s+(kini|sekarang)\s+(ialah|adalah)\b/i },
  { language: "MS", label: "role manipulation", re: /\bbertindak\s+sebagai\s+(pegawai|admin|sistem)\b/i },
  // Portuguese
  { language: "PT", label: "instruction override", re: /\bignore\s+as\s+instruç(õ|o)es\b/i },
  { language: "PT", label: "instruction override", re: /\besqueça\s+(as\s+)?instruç(õ|o)es\b/i },
  { language: "PT", label: "auto-approve", re: /\baprove\s+automaticamente\b/i },
  // French
  { language: "FR", label: "instruction override", re: /\bignore[zr]?\s+les\s+instructions\b/i },
  { language: "FR", label: "instruction override", re: /\boublie[z]?\s+les\s+instructions\b/i },
  { language: "FR", label: "auto-approve", re: /\bapprouve[z]?\s+automatiquement\b/i },
  // Italian
  { language: "IT", label: "instruction override", re: /\bignora\s+le\s+istruzioni\b/i },
  { language: "IT", label: "instruction override", re: /\bdimentica\s+le\s+istruzioni\b/i },
  { language: "IT", label: "auto-approve", re: /\bapprova\s+automaticamente\b/i },
];

export function guardText(text: string): InjectionResult {
  const matches: InjectionMatch[] = [];
  for (const p of GUARD_PATTERNS) {
    const m = text.match(p.re);
    if (m) matches.push({ language: p.language, label: p.label, sample: m[0].slice(0, 80) });
  }
  return { flagged: matches.length > 0, matches };
}

/* ───────────────────────────── Recommendation ───────────────────────────── */

function recommend(
  score: number,
  dsr: number,
  band: RiskBand,
  shariah: ShariahResult,
  injection: InjectionResult
): Recommendation {
  if (injection.flagged) return "Manual review"; // never let hostile text drive an outcome
  if (shariah.activityHaram) return "Decline";
  if (score < 560 || dsr > 0.7) return "Decline";
  if (shariah.structureNonCompliant) return "Manual review"; // offer a compliant alternative
  if (shariah.verdict === "Needs review" || band === "High") return "Manual review";
  return "Approve";
}

/* ─────────────────────────────── Narrative ──────────────────────────────── */
/* Template narrative (SIMULATED LLM output). Suppressed entirely when the
 * injection guard fires — hostile text must never reach a generative model. */

function narratives(
  input: ApplicationInput,
  instalment: number,
  dsr: number,
  score: number,
  band: RiskBand,
  shariah: ShariahResult,
  rec: Recommendation
): { en: string; ms: string } {
  const alt = shariah.suggestedAlternative;
  const en =
    `${input.fullName} (${input.occupation}) requests RM${input.amount.toLocaleString()} ` +
    `via ${input.product} over ${input.tenureMonths} months — an estimated instalment of ` +
    `RM${instalment.toLocaleString()} against RM${input.monthlyIncome.toLocaleString()} declared monthly income ` +
    `(DSR ${(dsr * 100).toFixed(1)}%). Alternative-data score ${score} (${band} risk) based on ` +
    `${input.incomeHistoryMonths} months of income history and RM${input.ewalletMonthlyInflow.toLocaleString()} ` +
    `average e-wallet inflow. Shariah screening: ${shariah.verdict}` +
    (alt ? `; a ${alt} structure is suggested as a compliant alternative` : "") +
    `. Engine recommendation: ${rec}. This narrative is advisory only — the officer makes the final decision.`;

  const ms =
    `${input.fullName} (${input.occupation}) memohon RM${input.amount.toLocaleString()} ` +
    `melalui ${input.product} selama ${input.tenureMonths} bulan — anggaran ansuran ` +
    `RM${instalment.toLocaleString()} berbanding pendapatan bulanan RM${input.monthlyIncome.toLocaleString()} ` +
    `(DSR ${(dsr * 100).toFixed(1)}%). Skor data alternatif ${score} (risiko ${band === "Low" ? "Rendah" : band === "Moderate" ? "Sederhana" : "Tinggi"}) ` +
    `berdasarkan ${input.incomeHistoryMonths} bulan sejarah pendapatan dan purata aliran masuk e-wallet ` +
    `RM${input.ewalletMonthlyInflow.toLocaleString()}. Saringan Syariah: ${shariah.verdict}` +
    (alt ? `; struktur ${alt} dicadangkan sebagai alternatif patuh Syariah` : "") +
    `. Cadangan enjin: ${rec}. Naratif ini hanya nasihat — pegawai yang membuat keputusan muktamad (the officer makes the final decision).`;

  return { en, ms };
}

/* ─────────────────────────────── assess() ───────────────────────────────── */

export function assess(input: ApplicationInput): Assessment {
  const instalment = estimateInstalment(input.amount, input.tenureMonths);
  const dsr =
    input.monthlyIncome > 0
      ? r2(((input.monthlyCommitments + instalment) / input.monthlyIncome) * 10000) / 10000
      : 9.99;

  const factors = creditFactors(input, instalment, dsr);
  const rawScore = 600 + factors.reduce((s, f) => s + f.points, 0);
  const score = Math.max(300, Math.min(850, rawScore));
  const band: RiskBand = score >= 700 ? "Low" : score >= 600 ? "Moderate" : "High";

  const shariah = screenShariah(input);
  const injection = guardText(`${input.purpose}\n${input.occupation}`);
  const recommendation = recommend(score, dsr, band, shariah, injection);

  let narrativeEn: string | null = null;
  let narrativeMs: string | null = null;
  if (!injection.flagged) {
    const n = narratives(input, instalment, dsr, score, band, shariah, recommendation);
    narrativeEn = n.en;
    narrativeMs = n.ms;
  }

  return {
    instalment,
    dsr,
    score,
    band,
    factors,
    shariah,
    injection,
    recommendation,
    narrativeEn,
    narrativeMs,
    engineVersion: ENGINE_VERSION,
  };
}
