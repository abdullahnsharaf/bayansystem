/** BAYAN — shared domain types. */

export const PRODUCTS = [
  "Murabahah",
  "Tawarruq",
  "Ijarah",
  "Conventional loan",
] as const;
export type Product = (typeof PRODUCTS)[number];

export const COMPLIANT_PRODUCTS = ["Murabahah", "Tawarruq", "Ijarah"] as const;
export type CompliantProduct = (typeof COMPLIANT_PRODUCTS)[number];

export interface ApplicationInput {
  fullName: string;
  occupation: string;
  product: Product;
  purpose: string;
  /** Financing amount requested, RM */
  amount: number;
  /** Tenure in months */
  tenureMonths: number;
  /** Self-declared monthly income, RM (SIMULATED — open banking in production) */
  monthlyIncome: number;
  /** Existing monthly commitments, RM */
  monthlyCommitments: number;
  /** Months of continuous income history on the platform(s) */
  incomeHistoryMonths: number;
  /** Average monthly e-wallet inflow, RM (SIMULATED — e-wallet API in production) */
  ewalletMonthlyInflow: number;
}

export interface ScoreFactor {
  label: string;
  points: number;
  note: string;
}

export type RiskBand = "Low" | "Moderate" | "High";

export type ShariahCategory =
  | "Riba"
  | "Haram activity"
  | "Maysir"
  | "Gharar"
  | "Structure";

export interface ShariahFinding {
  category: ShariahCategory;
  /** non_compliant blocks approval; review asks the officer to look closer */
  level: "non_compliant" | "review";
  detail: string;
  /** The exact text / condition that triggered the finding (explainability) */
  trigger: string;
}

export type ShariahVerdict = "Compliant" | "Needs review" | "Non-compliant";

export interface ShariahResult {
  verdict: ShariahVerdict;
  findings: ShariahFinding[];
  /** Haram activity or Maysir — no Islamic structure can fix the activity */
  activityHaram: boolean;
  /** The structure (not the activity) is the problem — substitution possible */
  structureNonCompliant: boolean;
  suggestedAlternative: CompliantProduct | null;
}

export interface InjectionMatch {
  language: string;
  label: string;
  sample: string;
}

export interface InjectionResult {
  flagged: boolean;
  matches: InjectionMatch[];
}

export type Recommendation = "Approve" | "Manual review" | "Decline";

export interface Assessment {
  /** Estimated monthly instalment, RM (flat 6.5% p.a. profit rate, SIMULATED) */
  instalment: number;
  /** Debt service ratio = (commitments + instalment) / income */
  dsr: number;
  score: number;
  band: RiskBand;
  factors: ScoreFactor[];
  shariah: ShariahResult;
  injection: InjectionResult;
  recommendation: Recommendation;
  /** null when the injection guard fires (narrative suppressed) */
  narrativeEn: string | null;
  narrativeMs: string | null;
  engineVersion: string;
}

export type ApplicationStatus =
  | "Pending"
  | "Approved"
  | "Alternative offered"
  | "Declined";

export type DecisionAction = Exclude<ApplicationStatus, "Pending">;

export interface Decision {
  action: DecisionAction;
  by: string; // officer sub
  byUsername: string;
  note: string;
  alternativeProduct?: CompliantProduct;
  at: string; // ISO timestamp
}

export interface Application {
  id: string;
  createdAt: string;
  ownerSub: string;
  ownerUsername: string;
  input: ApplicationInput;
  assessment: Assessment;
  status: ApplicationStatus;
  decision: Decision | null;
}

export interface AuditEntry {
  seq: number;
  ts: string;
  actor: string; // sub, or "system"
  actorUsername: string;
  role: string;
  action: string;
  target: string;
  details: Record<string, unknown>;
  prevHash: string;
  hash: string;
}

export interface VaultItem {
  id: string;
  label: string;
  /** Tide ciphertext only — the server never sees plaintext */
  ciphertext: string;
  createdAt: string;
}

export interface Db {
  applications: Application[];
  audit: AuditEntry[];
  /** keyed by owner sub */
  vault: Record<string, VaultItem[]>;
  meta: { seeded: boolean; createdAt: string };
}
