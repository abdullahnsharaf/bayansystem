/**
 * BAYAN — shared configuration (safe to import on server and client).
 *
 * tidecloak.json is `{}` until `npm run init` provisions the realm and writes
 * the real adapter config. Everything that touches TideCloak must therefore
 * check `isConfigured` and degrade to the setup screen instead of crashing.
 */
import raw from "@/tidecloak.json";

export const tcConfig = raw as Record<string, unknown>;

export const isConfigured =
  typeof tcConfig["auth-server-url"] === "string" &&
  typeof tcConfig["realm"] === "string";

export const APP_NAME = "BAYAN";

/** Tag used for Tide self-encryption of vault items (matches the
 *  `_tide_vault.selfencrypt` / `_tide_vault.selfdecrypt` realm roles). */
export const VAULT_TAG = "vault";

export const ROLES = {
  applicant: "applicant",
  officer: "officer",
  auditor: "auditor",
  vaultEncrypt: "_tide_vault.selfencrypt",
  vaultDecrypt: "_tide_vault.selfdecrypt",
} as const;

export type BayanRole = "applicant" | "officer" | "auditor";
