/**
 * BAYAN — JSON-file data store (SIMULATED persistence) + tamper-evident audit.
 *
 * Prototype store at .data/bayan.json with atomic writes (temp file + rename).
 * The API contracts are store-agnostic, so production swaps this file for
 * Postgres + row-level security without touching a single route.
 *
 * The audit chain is REAL: every entry's SHA-256 hash covers its content plus
 * the previous entry's hash, so editing or deleting any row breaks the chain
 * and `verifyChain` pinpoints where. (Prototype keeps the chain in-app;
 * production anchors it in write-once storage.)
 */
import fs from "node:fs";
import path from "node:path";
import { createHash, randomUUID } from "node:crypto";
import type {
  Application,
  AuditEntry,
  ApplicationInput,
  CompliantProduct,
  Db,
  Decision,
  DecisionAction,
  VaultItem,
} from "@/lib/types";
import { COMPLIANT_PRODUCTS } from "@/lib/types";
import { assess } from "@/lib/engine";
import { SEED_APPLICANTS } from "@/lib/seeds";
import type { Caller } from "@/lib/server/auth";

const DATA_DIR = path.join(process.cwd(), ".data");
const DATA_FILE = path.join(DATA_DIR, "bayan.json");

export const GENESIS_PREV_HASH = "0".repeat(64);

/* ───────────────────────────── hashing / chain ──────────────────────────── */

/** Deterministic serialisation with a FIXED key order, so the hash is stable. */
function canonical(entry: Omit<AuditEntry, "hash">): string {
  return JSON.stringify({
    seq: entry.seq,
    ts: entry.ts,
    actor: entry.actor,
    actorUsername: entry.actorUsername,
    role: entry.role,
    action: entry.action,
    target: entry.target,
    details: entry.details,
    prevHash: entry.prevHash,
  });
}

export function hashAuditEntry(entry: Omit<AuditEntry, "hash">): string {
  return createHash("sha256").update(canonical(entry)).digest("hex");
}

export function verifyChain(
  entries: AuditEntry[]
): { ok: true } | { ok: false; brokenAt: number } {
  let prev = GENESIS_PREV_HASH;
  for (const e of entries) {
    const { hash, ...rest } = e;
    if (e.prevHash !== prev || hashAuditEntry(rest) !== hash) {
      return { ok: false, brokenAt: e.seq };
    }
    prev = hash;
  }
  return { ok: true };
}

/* ─────────────────────────────── persistence ────────────────────────────── */

function emptyDb(): Db {
  return {
    applications: [],
    audit: [],
    vault: {},
    meta: { seeded: false, createdAt: new Date().toISOString() },
  };
}

function readDb(): Db {
  try {
    const raw = fs.readFileSync(DATA_FILE, "utf-8");
    return JSON.parse(raw) as Db;
  } catch {
    return emptyDb();
  }
}

/** Atomic write: temp file in the same directory, then rename. */
function persist(db: Db): void {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  const tmp = `${DATA_FILE}.tmp-${process.pid}-${randomUUID().slice(0, 8)}`;
  fs.writeFileSync(tmp, JSON.stringify(db, null, 2), "utf-8");
  fs.renameSync(tmp, DATA_FILE);
}

function appendAudit(
  db: Db,
  e: {
    actor: string;
    actorUsername: string;
    role: string;
    action: string;
    target: string;
    details?: Record<string, unknown>;
  }
): AuditEntry {
  const prevHash = db.audit.length > 0 ? db.audit[db.audit.length - 1].hash : GENESIS_PREV_HASH;
  const withoutHash: Omit<AuditEntry, "hash"> = {
    seq: db.audit.length + 1,
    ts: new Date().toISOString(),
    actor: e.actor,
    actorUsername: e.actorUsername,
    role: e.role,
    action: e.action,
    target: e.target,
    details: e.details ?? {},
    prevHash,
  };
  const entry: AuditEntry = { ...withoutHash, hash: hashAuditEntry(withoutHash) };
  db.audit.push(entry);
  return entry;
}

function nextAppId(db: Db): string {
  return `APP-${String(db.applications.length + 1).padStart(4, "0")}`;
}

function seed(db: Db): void {
  appendAudit(db, {
    actor: "system",
    actorUsername: "system",
    role: "system",
    action: "SYSTEM_BOOTSTRAP",
    target: "store",
    details: { note: "Store created; 6 demo applicants seeded (SIMULATED demo data)." },
  });
  for (const s of SEED_APPLICANTS) {
    const id = nextAppId(db);
    const app: Application = {
      id,
      createdAt: new Date().toISOString(),
      ownerSub: s.ownerSub,
      ownerUsername: s.ownerUsername,
      input: s.input,
      assessment: assess(s.input),
      status: "Pending",
      decision: null,
    };
    db.applications.push(app);
    appendAudit(db, {
      actor: "system",
      actorUsername: "system",
      role: "system",
      action: "SEED_APPLICATION",
      target: id,
      details: {
        applicant: s.input.fullName,
        product: s.input.product,
        amount: s.input.amount,
        recommendation: app.assessment.recommendation,
      },
    });
  }
  db.meta.seeded = true;
}

/**
 * Load-mutate-persist under a single synchronous critical section.
 * (Node runs this module single-threaded; writes themselves are atomic.)
 */
function withDb<T>(fn: (db: Db) => T): T {
  const db = readDb();
  if (!db.meta.seeded) seed(db);
  const result = fn(db);
  persist(db);
  return result;
}

/** Read-only access (still seeds on very first touch so demo data exists). */
function readOnly<T>(fn: (db: Db) => T): T {
  const db = readDb();
  if (!db.meta.seeded) {
    seed(db);
    persist(db);
  }
  return fn(db);
}

/* ───────────────────────────── applications ─────────────────────────────── */

export function listApplications(ownerSub?: string): Application[] {
  return readOnly((db) => {
    const apps = ownerSub
      ? db.applications.filter((a) => a.ownerSub === ownerSub)
      : db.applications;
    return [...apps].sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  });
}

export function getApplication(id: string): Application | null {
  return readOnly((db) => db.applications.find((a) => a.id === id) ?? null);
}

export function createApplication(caller: Caller, input: ApplicationInput): Application {
  return withDb((db) => {
    const id = nextAppId(db);
    const app: Application = {
      id,
      createdAt: new Date().toISOString(),
      ownerSub: caller.sub,
      ownerUsername: caller.username,
      input,
      assessment: assess(input),
      status: "Pending",
      decision: null,
    };
    db.applications.push(app);
    appendAudit(db, {
      actor: caller.sub,
      actorUsername: caller.username,
      role: "applicant",
      action: "APPLICATION_SUBMITTED",
      target: id,
      details: {
        product: input.product,
        amount: input.amount,
        recommendation: app.assessment.recommendation,
        injectionFlagged: app.assessment.injection.flagged,
      },
    });
    return app;
  });
}

export type DecisionResult =
  | { ok: true; app: Application }
  | { ok: false; status: 400 | 403 | 404 | 409 | 422; error: string };

export function decideApplication(
  caller: Caller,
  id: string,
  action: DecisionAction,
  note: string,
  alternativeProduct?: CompliantProduct
): DecisionResult {
  return withDb((db) => {
    const app = db.applications.find((a) => a.id === id);
    if (!app) return { ok: false as const, status: 404 as const, error: "Application not found." };

    // ── Segregation of duties: an officer can NEVER decide their own file ──
    if (app.ownerSub === caller.sub) {
      appendAudit(db, {
        actor: caller.sub,
        actorUsername: caller.username,
        role: "officer",
        action: "DECISION_BLOCKED_SOD",
        target: id,
        details: {
          attempted: action,
          reason: "Officer attempted to decide their own application (segregation of duties).",
        },
      });
      return {
        ok: false as const,
        status: 403 as const,
        error:
          "Blocked: segregation of duties. You cannot decide your own application — this attempt has been recorded in the audit trail.",
      };
    }

    if (app.status !== "Pending")
      return {
        ok: false as const,
        status: 409 as const,
        error: `Already decided: ${app.status}.`,
      };

    // ── A non-compliant structure can never be approved ──
    if (action === "Approved" && app.assessment.shariah.verdict === "Non-compliant") {
      appendAudit(db, {
        actor: caller.sub,
        actorUsername: caller.username,
        role: "officer",
        action: "DECISION_BLOCKED_NONCOMPLIANT",
        target: id,
        details: {
          attempted: "Approved",
          verdict: app.assessment.shariah.verdict,
          findings: app.assessment.shariah.findings.map((f) => f.category),
        },
      });
      return {
        ok: false as const,
        status: 422 as const,
        error:
          "This structure is Shariah non-compliant and cannot be approved. Offer a compliant alternative or decline.",
      };
    }

    if (action === "Alternative offered") {
      if (!alternativeProduct || !COMPLIANT_PRODUCTS.includes(alternativeProduct)) {
        return {
          ok: false as const,
          status: 400 as const,
          error: `"Alternative offered" requires a compliant product (${COMPLIANT_PRODUCTS.join(", ")}).`,
        };
      }
    }

    const decision: Decision = {
      action,
      by: caller.sub,
      byUsername: caller.username,
      note,
      at: new Date().toISOString(),
      ...(action === "Alternative offered" ? { alternativeProduct } : {}),
    };
    app.status = action;
    app.decision = decision;

    appendAudit(db, {
      actor: caller.sub,
      actorUsername: caller.username,
      role: "officer",
      action: "DECISION_RECORDED",
      target: id,
      details: {
        decision: action,
        ...(alternativeProduct ? { alternativeProduct } : {}),
        notePreview: note.slice(0, 80),
      },
    });

    return { ok: true as const, app };
  });
}

export function exportRegister(caller: Caller): {
  generatedAt: string;
  generatedBy: string;
  applications: Application[];
} {
  return withDb((db) => {
    appendAudit(db, {
      actor: caller.sub,
      actorUsername: caller.username,
      role: "auditor",
      action: "REGISTER_EXPORTED",
      target: "applications",
      details: { count: db.applications.length },
    });
    return {
      generatedAt: new Date().toISOString(),
      generatedBy: caller.username,
      applications: [...db.applications].sort((a, b) => a.id.localeCompare(b.id)),
    };
  });
}

/* ──────────────────────────────── audit ─────────────────────────────────── */

export function getAudit(): {
  entries: AuditEntry[];
  chain: { ok: true } | { ok: false; brokenAt: number };
} {
  return readOnly((db) => ({ entries: [...db.audit], chain: verifyChain(db.audit) }));
}

/* ──────────────────────────────── vault ─────────────────────────────────── */
/* The server only ever stores Tide CIPHERTEXT. Decryption happens in the
 * applicant's browser via their own Tide-held keys — a breached database (or
 * a curious admin) gets nothing readable.                                    */

export function getVault(sub: string): VaultItem[] {
  return readOnly((db) => [...(db.vault[sub] ?? [])]);
}

export function addVaultItem(caller: Caller, label: string, ciphertext: string): VaultItem {
  return withDb((db) => {
    const item: VaultItem = {
      id: randomUUID(),
      label,
      ciphertext,
      createdAt: new Date().toISOString(),
    };
    db.vault[caller.sub] = [...(db.vault[caller.sub] ?? []), item];
    appendAudit(db, {
      actor: caller.sub,
      actorUsername: caller.username,
      role: "applicant",
      action: "VAULT_ITEM_ADDED",
      target: item.id,
      details: { label, ciphertextLength: ciphertext.length },
    });
    return item;
  });
}

export function deleteVaultItem(caller: Caller, id: string): boolean {
  return withDb((db) => {
    const items = db.vault[caller.sub] ?? [];
    const idx = items.findIndex((i) => i.id === id);
    if (idx === -1) return false;
    const [removed] = items.splice(idx, 1);
    db.vault[caller.sub] = items;
    appendAudit(db, {
      actor: caller.sub,
      actorUsername: caller.username,
      role: "applicant",
      action: "VAULT_ITEM_DELETED",
      target: id,
      details: { label: removed.label },
    });
    return true;
  });
}
