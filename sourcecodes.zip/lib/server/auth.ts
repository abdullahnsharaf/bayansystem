/**
 * BAYAN — server-side identity. EVERY API route starts here.
 *
 * The UI is never trusted: the proxy gates pages for UX, but this is the real
 * security boundary. The JWT is re-verified cryptographically against the
 * realm's keys (TideCloak's decentralised authority) on every request, and the
 * required role must be present in the token itself.
 */
import { NextRequest, NextResponse } from "next/server";
import { verifyTideCloakToken } from "@tidecloak/nextjs/server";
import { isConfigured, tcConfig } from "@/lib/config";

export interface Caller {
  sub: string;
  username: string;
  vuid: string;
  roles: string[];
}

export type RequireRoleResult =
  | { caller: Caller; error?: undefined }
  | { caller?: undefined; error: NextResponse };

function jsonError(status: number, error: string): NextResponse {
  return NextResponse.json({ error }, { status });
}

/** Extract the access token: Authorization: Bearer … first, kcToken cookie as fallback. */
function extractToken(req: NextRequest): string | null {
  const header = req.headers.get("authorization");
  if (header && header.toLowerCase().startsWith("bearer ")) {
    const t = header.slice(7).trim();
    if (t) return t;
  }
  return req.cookies.get("kcToken")?.value ?? null;
}

export async function requireRole(
  req: NextRequest,
  allowedRoles: string[]
): Promise<RequireRoleResult> {
  if (!isConfigured) {
    return {
      error: jsonError(
        503,
        "TideCloak is not initialised. Start the TideCloak container and run `npm run init`."
      ),
    };
  }

  const token = extractToken(req);
  if (!token) {
    return { error: jsonError(401, "Unauthorized: no access token provided.") };
  }

  try {
    const payload = (await verifyTideCloakToken(
      tcConfig as object,
      token,
      allowedRoles
    )) as Record<string, unknown> | null;

    if (!payload) {
      return {
        error: jsonError(
          403,
          `Forbidden: token invalid or missing a required role (${allowedRoles.join(" | ")}).`
        ),
      };
    }

    const realmAccess = payload["realm_access"] as { roles?: string[] } | undefined;
    const resourceAccess = payload["resource_access"] as
      | Record<string, { roles?: string[] }>
      | undefined;
    const roles = Array.from(
      new Set([
        ...(realmAccess?.roles ?? []),
        ...Object.values(resourceAccess ?? {}).flatMap((r) => r?.roles ?? []),
      ])
    );

    const caller: Caller = {
      sub: String(payload["sub"] ?? ""),
      username: String(payload["preferred_username"] ?? payload["sub"] ?? "unknown"),
      vuid: String(payload["vuid"] ?? ""),
      roles,
    };
    return { caller };
  } catch {
    // Signature/claim failures and malformed tokens all land here — a clean
    // JSON 403, never a stack trace.
    return { error: jsonError(403, "Forbidden: token verification failed.") };
  }
}
