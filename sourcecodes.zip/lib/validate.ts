/** BAYAN — server-side input validation. Never trust the UI. */
import { PRODUCTS, type ApplicationInput, type Product } from "./types";

export interface FieldError {
  field: string;
  message: string;
}

export type ValidationResult =
  | { ok: true; value: ApplicationInput }
  | { ok: false; fields: FieldError[] };

function str(v: unknown): string | null {
  return typeof v === "string" ? v.trim() : null;
}
function num(v: unknown): number | null {
  const n = typeof v === "number" ? v : typeof v === "string" && v.trim() !== "" ? Number(v) : NaN;
  return Number.isFinite(n) ? n : null;
}

export function validateApplicationInput(body: unknown): ValidationResult {
  const fields: FieldError[] = [];
  const b = (body ?? {}) as Record<string, unknown>;

  const fullName = str(b.fullName);
  if (!fullName || fullName.length < 3 || fullName.length > 80)
    fields.push({ field: "fullName", message: "Full name must be 3–80 characters." });

  const occupation = str(b.occupation);
  if (!occupation || occupation.length < 2 || occupation.length > 80)
    fields.push({ field: "occupation", message: "Occupation must be 2–80 characters." });

  const purpose = str(b.purpose);
  if (!purpose || purpose.length < 8 || purpose.length > 600)
    fields.push({ field: "purpose", message: "Purpose must be 8–600 characters." });

  const productRaw = str(b.product);
  const product = PRODUCTS.find((p) => p === productRaw) as Product | undefined;
  if (!product)
    fields.push({ field: "product", message: `Product must be one of: ${PRODUCTS.join(", ")}.` });

  const amount = num(b.amount);
  if (amount === null || amount < 500 || amount > 200000)
    fields.push({ field: "amount", message: "Amount must be RM500–RM200,000." });

  const tenureMonths = num(b.tenureMonths);
  if (tenureMonths === null || !Number.isInteger(tenureMonths) || tenureMonths < 3 || tenureMonths > 120)
    fields.push({ field: "tenureMonths", message: "Tenure must be a whole number of months, 3–120." });

  const monthlyIncome = num(b.monthlyIncome);
  if (monthlyIncome === null || monthlyIncome < 300 || monthlyIncome > 100000)
    fields.push({ field: "monthlyIncome", message: "Monthly income must be RM300–RM100,000." });

  const monthlyCommitments = num(b.monthlyCommitments);
  if (monthlyCommitments === null || monthlyCommitments < 0 || monthlyCommitments > 100000)
    fields.push({ field: "monthlyCommitments", message: "Commitments must be RM0–RM100,000." });

  const incomeHistoryMonths = num(b.incomeHistoryMonths);
  if (
    incomeHistoryMonths === null ||
    !Number.isInteger(incomeHistoryMonths) ||
    incomeHistoryMonths < 0 ||
    incomeHistoryMonths > 600
  )
    fields.push({ field: "incomeHistoryMonths", message: "Income history must be 0–600 whole months." });

  const ewalletMonthlyInflow = num(b.ewalletMonthlyInflow);
  if (ewalletMonthlyInflow === null || ewalletMonthlyInflow < 0 || ewalletMonthlyInflow > 1000000)
    fields.push({ field: "ewalletMonthlyInflow", message: "E-wallet inflow must be RM0–RM1,000,000." });

  if (fields.length > 0) return { ok: false, fields };

  return {
    ok: true,
    value: {
      fullName: fullName!,
      occupation: occupation!,
      purpose: purpose!,
      product: product!,
      amount: amount!,
      tenureMonths: tenureMonths!,
      monthlyIncome: monthlyIncome!,
      monthlyCommitments: monthlyCommitments!,
      incomeHistoryMonths: incomeHistoryMonths!,
      ewalletMonthlyInflow: ewalletMonthlyInflow!,
    },
  };
}
