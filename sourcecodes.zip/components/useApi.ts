"use client";

import { useCallback } from "react";
import { useTideCloak } from "@tidecloak/nextjs";

/**
 * Fetch wrapper for BAYAN's APIs: refreshes the TideCloak token when needed
 * (getToken() handles refresh) and attaches it as a Bearer header. Every API
 * route re-verifies this token server-side — the header is transport, not trust.
 */
export function useApi() {
  const { getToken, token } = useTideCloak();

  return useCallback(
    async (path: string, init: RequestInit = {}): Promise<Response> => {
      let t: string | null = null;
      try {
        t = await getToken();
      } catch {
        t = token;
      }
      const headers = new Headers(init.headers);
      if (init.body && !headers.has("Content-Type")) {
        headers.set("Content-Type", "application/json");
      }
      if (t) headers.set("Authorization", `Bearer ${t}`);
      return fetch(path, { ...init, headers });
    },
    [getToken, token]
  );
}
