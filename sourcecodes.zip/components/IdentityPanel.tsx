"use client";

import { useEffect, useState } from "react";
import { useTideCloak } from "@tidecloak/nextjs";
import { useApi } from "@/components/useApi";
import { ROLES } from "@/lib/config";

interface Me {
  serverVerified: boolean;
  checkedAt: string;
  sub: string;
  username: string;
  vuid: string;
  roles: string[];
}

/**
 * "Verified by TideCloak (server-side)": the contents of this card come from
 * /api/me, which cryptographically re-verifies the JWT on the server — not
 * from anything the browser claims about itself.
 */
export function IdentityPanel() {
  const api = useApi();
  const { tokenExp, hasRealmRole } = useTideCloak();
  const [me, setMe] = useState<Me | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [now, setNow] = useState<number>(() => Date.now());

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const res = await api("/api/me");
        const data = await res.json();
        if (!alive) return;
        if (res.ok) setMe(data as Me);
        else setError(String(data.error ?? `HTTP ${res.status}`));
      } catch (e) {
        if (alive) setError(e instanceof Error ? e.message : "Network error");
      }
    })();
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => {
      alive = false;
      clearInterval(t);
    };
  }, [api]);

  const secondsLeft = tokenExp ? Math.max(0, Math.floor(tokenExp - now / 1000)) : null;
  const mm = secondsLeft !== null ? String(Math.floor(secondsLeft / 60)).padStart(2, "0") : "--";
  const ss = secondsLeft !== null ? String(secondsLeft % 60).padStart(2, "0") : "--";

  return (
    <div className="card">
      <h3>
        Verified by TideCloak <span className="badge b-compliant">server-side</span>
      </h3>
      {error ? (
        <div className="alert alert-danger">/api/me: {error}</div>
      ) : !me ? (
        <p className="muted">Verifying token on the server…</p>
      ) : (
        <dl className="kv">
          <dt>User</dt>
          <dd>
            <b>{me.username}</b>
          </dd>
          <dt>Tide vuid</dt>
          <dd className="mono">{me.vuid || "—"}</dd>
          <dt>Roles (from token)</dt>
          <dd>
            {me.roles
              .filter((r) => !r.startsWith("default-roles") && r !== "offline_access" && r !== "uma_authorization")
              .map((r) => (
                <span key={r} className="badge b-pending" style={{ marginRight: 4 }}>
                  {r}
                </span>
              ))}
          </dd>
          <dt>Encryption rights</dt>
          <dd>
            self-encrypt {hasRealmRole(ROLES.vaultEncrypt) ? "✓" : "✗"} · self-decrypt{" "}
            {hasRealmRole(ROLES.vaultDecrypt) ? "✓" : "✗"}{" "}
            <span className="muted">(tag: vault)</span>
          </dd>
          <dt>Token expires in</dt>
          <dd className="mono">
            {mm}:{ss}
          </dd>
          <dt>Checked at</dt>
          <dd className="mono">{new Date(me.checkedAt).toLocaleTimeString()}</dd>
        </dl>
      )}
      <p className="muted" style={{ marginBottom: 0 }}>
        BAYAN stores no passwords. Identity, roles and encryption rights come from your Tide
        account via TideCloak — verified cryptographically on every request.
      </p>
    </div>
  );
}
