"use client";

import Link from "next/link";
import type { ReactNode } from "react";
import { useTideCloak } from "@tidecloak/nextjs";
import { ROLES } from "@/lib/config";

const NAV: { role: string; href: string; label: string }[] = [
  { role: ROLES.applicant, href: "/applicant", label: "My applications" },
  { role: ROLES.officer, href: "/officer", label: "Officer review" },
  { role: ROLES.auditor, href: "/auditor", label: "Audit trail" },
];

/**
 * Workspace chrome. Links appear ONLY for roles the signed-in user actually
 * holds (hasRealmRole) — and even if a link were forged, the proxy and every
 * API verify the role server-side.
 */
export function AppShell({
  active,
  title,
  subtitle,
  children,
}: {
  active: "/applicant" | "/officer" | "/auditor";
  title: string;
  subtitle?: string;
  children: ReactNode;
}) {
  const { isInitializing, authenticated, logout, hasRealmRole, getValueFromIdToken } =
    useTideCloak();

  if (isInitializing) {
    return (
      <div className="center-screen">
        <p className="muted">Connecting to TideCloak…</p>
      </div>
    );
  }

  if (!authenticated) {
    return (
      <div className="center-screen">
        <div className="setup-card">
          <h2>Session required</h2>
          <p className="muted">
            You are not signed in. <Link href="/">Return to the landing page</Link> and sign in
            with Tide.
          </p>
        </div>
      </div>
    );
  }

  const username = String(getValueFromIdToken("preferred_username") ?? "user");
  const myRoles = [ROLES.applicant, ROLES.officer, ROLES.auditor].filter((r) =>
    hasRealmRole(r)
  );

  return (
    <div className="shell">
      <aside className="sidebar">
        <div className="side-logo">
          <h1>
            BAYAN <span className="brand-ar">بَيَان</span>
          </h1>
          <div className="side-tag">Shariah-first micro-financing · zero blind trust</div>
        </div>

        <nav className="side-nav">
          {NAV.filter((n) => hasRealmRole(n.role)).map((n) => (
            <Link key={n.href} href={n.href} className={n.href === active ? "active" : ""}>
              {n.label}
            </Link>
          ))}
        </nav>

        <div className="side-spacer" />

        <span className="side-badge">
          <span className="dot" /> Secured by TideCloak
        </span>

        <div className="side-user">
          <div className="u">{username}</div>
          <div className="side-roles">
            {myRoles.map((r) => (
              <span key={r} className="chip">
                {r}
              </span>
            ))}
          </div>
          <button className="btn btn-sm" onClick={() => logout()}>
            Sign out
          </button>
        </div>
      </aside>

      <main className="main">
        <div className="page-head">
          <h2>{title}</h2>
          {subtitle ? <div className="sub">{subtitle}</div> : null}
        </div>
        {children}
      </main>
    </div>
  );
}
