/** Honesty tag: anything mocked for the demo is visibly marked in the UI. */
export function Sim({ label = "SIMULATED" }: { label?: string }) {
  return (
    <span className="sim-tag" title="Mocked for the prototype — see the SIMULATED components table in the README">
      {label}
    </span>
  );
}
