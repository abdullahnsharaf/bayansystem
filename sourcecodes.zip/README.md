# BAYAN بَيَان — Shariah-first micro-financing without blind trust

**RMIT Hackathon 2026 · Challenge 2 (TideCloak Vibe Coding)**
A working Next.js 16 prototype: Shariah-compliant micro-financing for Malaysia's B40 and gig-economy workers, built on the assumption that **we will be breached — and it must not matter.**

> Submission contents: this repo = run instructions (below) · `sourcecodes.zip` · `summary.doc` · `video.mp4` (2-minute demo).
> Everything mocked is tagged **SIMULATED** in the UI and listed in the [table below](#mocked--simulated-components).

---

## 1 · The problem

E-hailing drivers, delivery riders and home sellers earn real, steady income — but have no payslips, so Islamic banks cannot score them and they fall back on informal (often interest-bearing) credit. BAYAN assesses them on **alternative data**: months of income history, e-wallet inflow and existing commitments, screened through a Shariah-first engine (Riba · Haram activity · Maysir · Gharar · structure fit) that can *substitute* a compliant contract (Murabahah / Tawarruq / Ijarah) instead of simply declining.

## 2 · The trust constraint

Collecting that data makes the platform a **honeypot**. The dangerous actor is whoever holds the keys:

| Threat | What normally happens | What BAYAN + TideCloak does |
|---|---|---|
| Leaked password database | Every account falls | **BAYAN stores no passwords.** Login is decentralised via TideCloak — keys are split across the Tide fabric; there is no credential table to steal. |
| Phished / rogue **admin** | Grants themself any role | Role grants are **IGA change-requests needing quorum approval** in TideCloak. One stolen admin cannot escalate alone. |
| DBA / server breach reads IC numbers | Plaintext PII exposed | The **private vault** encrypts in the *browser* (`doEncrypt`, tag `vault`) with keys only the user's Tide account controls. The server stores **ciphertext only** — breach yields nothing readable. |
| Officer approves their **own** loan | Insider fraud | **Segregation of duties enforced server-side**: the decision API compares the token's `sub` to the file's owner → `403` and a `DECISION_BLOCKED_SOD` audit entry. |
| Admin quietly **edits the logs** | Fraud disappears | Every audit event is **SHA-256-chained** to the previous one; the chain is re-verified on every read and the auditor page shows *exactly* which event broke. |
| Forged requests / trusted UI | Hidden buttons ≠ security | Pages are gated **server-side before render** (`proxy.ts`), and **every API re-verifies the JWT** (`verifyTideCloakToken`) + required realm role. The UI is never trusted. |
| Applicant free text attacks the AI | Prompt injection steers outcomes | An **AI-input guard** screens EN/MS/PT/FR/IT injection patterns; on a hit the narrative is suppressed and the engine forces *Manual review*. |
| Non-compliant structure slips through | Riba gets approved | The server returns `422` on any attempt to approve a *Non-compliant* structure — the engine proposes a compliant substitute instead. |

**Roles** (TideCloak realm roles): `applicant` (default for every new user, + `_tide_vault.selfencrypt/.selfdecrypt`), `officer`, `auditor`.

---

## 3 · Run it

Prerequisites: **Node 20+**, **Docker**, a free port **8080** (TideCloak) and **3000** (app).

```bash
# 1 · install
npm install

# 2 · start TideCloak (dev image)
docker run -d --name tidecloak \
  -p 8080:8080 \
  -e KC_BOOTSTRAP_ADMIN_USERNAME=admin \
  -e KC_BOOTSTRAP_ADMIN_PASSWORD=password \
  tideorg/tidecloak-dev:latest
# wait ~30–60 s until http://localhost:8080 answers

# 3 · provision the `bayan` realm (roles, client, Tide IdP, IGA) and
#     write the adapter config into tidecloak.json
npm run init

# 4 · run
npm run dev          # http://localhost:3000
```

Until step 3 completes, the app deliberately shows a **"Connect BAYAN to TideCloak"** setup screen instead of crashing (`tidecloak.json` is committed as `{}`).

`npm run init` ends by printing a **Tide enrolment link for the realm admin** — open it and link a Tide account, then sign in to the TideCloak console at `http://localhost:8080` (realm **bayan**) for the user steps below.

### Windows troubleshooting
* `npm run init` is a bash script. Run it from **Git Bash** or **WSL** (`bash init/tcinit.sh`), not PowerShell/cmd. It needs `curl` and `jq` (`winget install jqlang.jq`, or in WSL `sudo apt install jq`).
* If Docker Desktop uses WSL2 and `localhost:8080` is unreachable from Git Bash, retry from WSL, or re-run with `TIDECLOAK_LOCAL_URL=http://127.0.0.1:8080 npm run init`.
* CRLF issues: the init script is CRLF-safe; if bash still complains, `git config core.autocrlf false` and re-checkout.
* Port clash on 8080 → stop the other service or run the container on `-p 8081:8080` and `TIDECLOAK_LOCAL_URL=http://localhost:8081 npm run init`.
* Reset everything: `docker rm -f tidecloak`, delete `.data/` and reset `tidecloak.json` to `{}`, then repeat steps 2–3.

### Demo users (create once, in the TideCloak console → realm **bayan**)

| Username | Realm role to add | Workspace |
|---|---|---|
| `aisyah` | *(none — `applicant` is a default role)* | `/applicant` |
| `officer.hafiz` | `officer` | `/officer` |
| `auditor.lim` | `auditor` | `/auditor` |

For each user: **Users → Add user** → open the user → **Credentials/Actions → Link Tide account** (send/open the action link and enrol a Tide account) → **Role mapping → Assign role** (`officer` / `auditor`).
**IGA quorum:** each role assignment parks as a *pending change-request* — approve it under **Change Requests** before it takes effect. That approval step **is** the "one stolen admin cannot escalate" control; show it in the demo.

Useful scripts: `npm run selftest` (engine + audit-chain assertions, offline) · `npm run tamper` (edits one audit row so the auditor banner turns red) · `npm run build` (production build).

---

## 4 · Two-minute demo script

| ⏱ | Beat |
|---|---|
| 0:00 | Landing: the honeypot problem in one line. **Sign in with Tide** as `aisyah` — no password exists in BAYAN. |
| 0:15 | Applicant: IdentityPanel shows **server-verified** user, Tide `vuid`, roles, token expiry. Submit an application (self-declared data is tagged SIMULATED). |
| 0:35 | **Private vault:** type an IC number → *Encrypt in browser & store* → show "What the server sees" (ciphertext) → Decrypt. Say: "this encryption is real — a stolen database is unreadable." |
| 0:55 | Try to open `/officer` as aisyah → **Access denied (server-side)** page. |
| 1:05 | Sign in as `officer.hafiz`. Open the credit-card refinance → **Riba, Non-compliant**, Approve refuses (`422`) → **Offer alternative: Tawarruq**. Open the injection seed → red **AI-input guard** alert, narrative suppressed. |
| 1:30 | SoD: hafiz opens the application he submitted himself → Approve → **BLOCKED 403**, recorded in the audit chain. |
| 1:40 | Sign in as `auditor.lim`: green **chain intact** banner, the BLOCKED entry visible. Run `npm run tamper`, reload → **chain broken at #n**. Export CSV. |
| 1:55 | Close: "Every control was enforced by the server and TideCloak — not by hiding buttons." |

---

## 5 · Architecture

```
Browser (React 19)
│  TideCloakProvider · useTideCloak (login/logout, roles, token)
│  doEncrypt / doDecrypt  ← vault plaintext NEVER leaves the browser
▼
Next.js 16 (App Router, TypeScript, plain CSS)
│  proxy.ts            server-side page gating per realm role (kcToken)
│  app/api/*           EVERY route: requireRole() → verifyTideCloakToken
│    /api/me                       identity echo (server-verified)
│    /api/applications             list/create (validated) · PUT register export (audited)
│    /api/applications/[id]/decision   SoD 403 · 409 · 422 Shariah gate
│    /api/audit                    entries + verifyChain on every read
│    /api/vault                    ciphertext-only storage
│  lib/engine.ts       SIMULATED rules: score+factors · Shariah screen ·
│                      smart substitution · multilingual injection guard ·
│                      EN/BM narrative ("…the officer makes the final decision.")
│  lib/server/db.ts    .data/bayan.json (atomic writes) + SHA-256 audit chain
▼
TideCloak (Docker, realm `bayan`)   decentralised auth · realm roles ·
                                    IGA quorum change-requests · Tide IdP ·
                                    self-encryption rights (_tide_vault.*)
```

Engineering decisions and the production roadmap (Postgres + RLS, Tide policy-based decryption for officer-shared documents, open-banking/e-wallet/CCRIS feeds, XGBoost + SHAP, fatwa-RAG Shariah engine, the Challenge-1 XLM-R injection classifier as a service, multi-admin quorum threshold) are in `summary.doc`.

---

## 6 · MOCKED / SIMULATED components

Honesty rule: if it's mocked, it says so — in the UI and here. **Never claimed as Tide-encrypted: anything outside the vault.**

| Component | Status | Production replacement |
|---|---|---|
| Demo applicants (6 seeds) | **SIMULATED** (`lib/seeds.ts`) | Real onboarding |
| Income / e-wallet figures | **SIMULATED** (self-declared) | Open-banking, e-wallet & CCRIS APIs with consent |
| Credit scoring | **SIMULATED** transparent rules | XGBoost + SHAP explanations |
| Shariah screening | **SIMULATED** keyword screen (word-boundary regex) | Fatwa-grounded RAG + Shariah committee workflow |
| Prompt-injection guard | **SIMULATED** keyword patterns (EN/MS/PT/FR/IT) | Challenge-1 fine-tuned XLM-R classifier as a service |
| Advisory narrative (EN/BM) | **SIMULATED** template | Guarded LLM generation |
| Instalment pricing (6.5% p.a. flat) | **SIMULATED** | Bank product pricing |
| Data store | **SIMULATED** JSON file `.data/bayan.json` | Postgres + row-level security; audit anchored in write-once storage |
| **NOT simulated** | TideCloak login & decentralised keys · server-side role verification (proxy + every API) · browser-side vault encryption/decryption (`doEncrypt`/`doDecrypt`) · IGA quorum approvals · SHA-256 audit chain & tamper detection · SoD and `422` Shariah gate | — |

---

## 7 · Verification checklist (Phase 7)

Automated — all passing at submission time:
- [x] `npm run selftest` → 12/12: the six seeds give **Approve · alt-Tawarruq · Approve · Decline · Approve · injection-flagged**; MS/PT/FR/IT guard patterns fire; `interested` / `interest-free` do **not** trip Riba; chain verifies; tampering/deleting an entry → `brokenAt` at the right seq.
- [x] `requireRole`: no token → **401** · garbage token → **403** · forged JWT (header **and** `kcToken` cookie) → **403**; unprovisioned realm → clean **503** JSON, never a stack trace.
- [x] `curl /officer` with no cookie → **307 redirect** before render; `/` serves the setup screen when `tidecloak.json` is `{}`.
- [x] `npm run tamper` → auditor chain reports `{"ok":false,"brokenAt":2}`.
- [x] `npm run build` → production build + strict TypeScript pass.

Manual (with TideCloak running — walk during the demo):
- [ ] `aisyah` opening `/officer` → Access-denied page (server-side).
- [ ] Officer deciding **their own** application → 403 + `DECISION_BLOCKED_SOD` in the audit trail.
- [ ] Approving the conventional-loan seed → **422**; "Offer alternative" requires a compliant product.
- [ ] `.data/bayan.json` vault rows contain **no plaintext** (open the file).
- [ ] Role grant in the console only takes effect **after IGA change-request approval**.
