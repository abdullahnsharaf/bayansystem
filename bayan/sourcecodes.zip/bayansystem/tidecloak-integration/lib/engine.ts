import type { ApplicationInput, Assessment, Factor, Product, ShariahFinding } from "./types";

const PROFIT_RATE = 0.065; // indicative annual profit rate for the demo

const rm = (n: number) => `RM ${Math.round(n).toLocaleString("en-MY")}`;
const pct = (n: number) => `${Math.round(n * 100)}%`;

/* ---------------- 1. AI-input guard (links to Challenge 1) ----------------
 * Applicant free text is later fed to an AI narrative engine, so it is an
 * injection surface. These patterns cover EN / MS / PT / FR / IT phrasing.
 * In production this calls our fine-tuned XLM-R classifier (Challenge 1). */
const INJECTION_PATTERNS: [RegExp, string][] = [
  [/ignore (all |the )?(previous|prior|above) (instructions|rules)/i, "Instruction override (EN)"],
  [/(abaikan|lupakan) (semua )?(arahan|peraturan)/i, "Instruction override (BM)"],
  [/ignor(e|a)[rs]? (as |les |le )?(instru[cç][õo]es|instructions|istruzioni)/i, "Instruction override (PT/FR/IT)"],
  [/(system prompt|reveal your (rules|prompt)|developer mode|you are now|act as (an? )?(admin|officer))/i, "Role / system-prompt manipulation"],
  [/(auto-?approve|approve this (application|loan) (automatically|immediately)|set (score|status) to)/i, "Attempt to force a decision"],
];

export function guardText(text: string): { flagged: boolean; reasons: string[] } {
  const reasons = INJECTION_PATTERNS.filter(([re]) => re.test(text)).map(([, r]) => r);
  return { flagged: reasons.length > 0, reasons };
}

/* ---------------- 2. Shariah screening ---------------- */
const HARAM = /(alcohol|beer|wine|liquor|arak|casino|gambl|judi|betting|lottery|loteri|pork|babi|nightclub|tobacco|rokok)/i;
const SPECULATIVE = /(forex|crypto|bitcoin|day ?trading|options trading|spekulasi)/i;
const RIBA_TEXT = /(interest|faedah|compound|refinance (my )?(conventional|credit card)|bayar balik kad kredit)/i;
const GHARAR_TEXT = /(unspecified|not sure what|belum pasti|tak pasti|anything|whatever|surprise)/i;

function screenShariah(i: ApplicationInput): { verdict: Assessment["shariah"]["verdict"]; findings: ShariahFinding[] } {
  const f: ShariahFinding[] = [];
  if (i.product === "Conventional loan")
    f.push({ principle: "Riba", severity: "fail", detail: "Requested an interest-bearing conventional loan structure." });
  if (RIBA_TEXT.test(i.purpose))
    f.push({ principle: "Riba", severity: "warn", detail: "Purpose mentions interest-based debt; refinancing must use a Shariah-compliant contract." });
  if (HARAM.test(i.purpose))
    f.push({ principle: "Haram activity", severity: "fail", detail: "Purpose relates to a prohibited (non-halal) activity." });
  if (SPECULATIVE.test(i.purpose))
    f.push({ principle: "Maysir", severity: "fail", detail: "Purpose is speculative trading (maysir / gambling-like uncertainty)." });
  if (GHARAR_TEXT.test(i.purpose) || i.purpose.trim().length < 12)
    f.push({ principle: "Gharar", severity: "warn", detail: "Underlying asset or use of funds is not clearly specified (excessive uncertainty)." });
  if (i.product === "Ijarah" && !/\b(motor(cycle)?|car|cars|kereta|van|bike|equipment|peralatan|machine|mesin|laptop|rent|sewa)\b/i.test(i.purpose))
    f.push({ principle: "Structure", severity: "warn", detail: "Ijarah (leasing) needs an identifiable leasable asset." });

  const verdict = f.some((x) => x.severity === "fail") ? "Non-compliant" : f.length ? "Needs review" : "Compliant";
  return { verdict, findings: f };
}

/* ---------------- 3. Alternative product (Smart Substitution) ---------------- */
function suggestProduct(i: ApplicationInput, nonCompliantStructure: boolean): Product | null {
  if (!nonCompliantStructure) return null;
  if (/\b(motor(cycle)?|car|cars|kereta|van|bike|equipment|peralatan|machine|mesin|laptop)\b/i.test(i.purpose)) return "Ijarah";
  if (/\b(stock|stok|inventory|inventori|goods|barang|supplies|bekalan|oven)\b/i.test(i.purpose)) return "Murabahah";
  return "Tawarruq";
}

/* ---------------- 4. Credit assessment on alternative data ---------------- */
export function assess(i: ApplicationInput): Assessment {
  const totalPayable = i.amount * (1 + PROFIT_RATE * (i.tenureMonths / 12));
  const installment = totalPayable / Math.max(1, i.tenureMonths);
  const income = Math.max(1, i.monthlyIncome);
  const dsr = (i.commitments + installment) / income;

  const factors: Factor[] = [];
  let score = 600;
  const add = (label: string, impact: number, note: string) => {
    score += impact;
    factors.push({ label, impact, note });
  };

  if (dsr <= 0.3) add("Debt service ratio", 90, `${pct(dsr)} of income - comfortable`);
  else if (dsr <= 0.45) add("Debt service ratio", 40, `${pct(dsr)} of income - manageable`);
  else if (dsr <= 0.6) add("Debt service ratio", -30, `${pct(dsr)} of income - stretched`);
  else add("Debt service ratio", -120, `${pct(dsr)} of income - unaffordable`);

  if (i.incomeMonths >= 24) add("Income history", 60, `${i.incomeMonths} months verifiable gig income`);
  else if (i.incomeMonths >= 12) add("Income history", 30, `${i.incomeMonths} months verifiable gig income`);
  else if (i.incomeMonths >= 6) add("Income history", -10, `Only ${i.incomeMonths} months of history`);
  else add("Income history", -60, `Thin file: ${i.incomeMonths} months`);

  const flowRatio = i.ewalletInflow / income;
  if (flowRatio >= 0.8) add("E-wallet cash flow", 45, `${rm(i.ewalletInflow)}/month confirms declared income`);
  else if (flowRatio >= 0.5) add("E-wallet cash flow", 15, `Partially confirms declared income`);
  else add("E-wallet cash flow", -40, `Only ${pct(flowRatio)} of declared income seen in e-wallet`);

  const multiple = i.amount / income;
  if (multiple <= 3) add("Amount vs income", 30, `${multiple.toFixed(1)}x monthly income`);
  else if (multiple <= 8) add("Amount vs income", 0, `${multiple.toFixed(1)}x monthly income`);
  else add("Amount vs income", -50, `${multiple.toFixed(1)}x monthly income - large exposure`);

  score = Math.max(300, Math.min(850, Math.round(score)));
  const band = score >= 700 ? "Low risk" : score >= 600 ? "Moderate risk" : "High risk";

  const shariah = screenShariah(i);
  const guard = guardText(`${i.purpose} ${i.fullName} ${i.occupation}`);
  const structureFail = shariah.findings.some((x) => x.severity === "fail" && (x.principle === "Riba" || x.principle === "Structure"));
  const activityFail = shariah.findings.some((x) => x.severity === "fail" && (x.principle === "Haram activity" || x.principle === "Maysir"));
  const suggestedProduct = activityFail ? null : suggestProduct(i, structureFail);

  let recommendation: Assessment["recommendation"];
  if (activityFail || score < 560 || dsr > 0.7) recommendation = "Decline";
  else if (guard.flagged || shariah.verdict !== "Compliant" || score < 680 || dsr > 0.5) recommendation = "Manual review";
  else recommendation = "Approve";

  const top = [...factors].sort((a, b) => Math.abs(b.impact) - Math.abs(a.impact))[0];

  const narrativeEN = guard.flagged
    ? `AI narrative disabled: the applicant's text contains a possible prompt-injection attempt (${guard.reasons.join(", ")}). Manual review is required.`
    : `${i.fullName} (${i.occupation}) requests ${rm(i.amount)} over ${i.tenureMonths} months via ${i.product}. ` +
      `Estimated instalment is ${rm(installment)}, giving a debt service ratio of ${pct(dsr)}. ` +
      `The credit score is ${score} (${band.toLowerCase()}); the strongest factor is ${top.label.toLowerCase()} (${top.note}). ` +
      `Shariah screening: ${shariah.verdict.toLowerCase()}` +
      (shariah.findings.length ? ` - ${shariah.findings.map((x) => x.principle).join(", ")}.` : ".") +
      (suggestedProduct ? ` Recommended compliant alternative: ${suggestedProduct}.` : "") +
      ` Recommendation: ${recommendation.toLowerCase()}. The officer makes the final decision.`;

  const recBM = { Approve: "lulus", "Manual review": "semakan manual", Decline: "tolak" }[recommendation];
  const verBM = { Compliant: "patuh Syariah", "Needs review": "perlu semakan Syariah", "Non-compliant": "tidak patuh Syariah" }[shariah.verdict];
  const narrativeBM = guard.flagged
    ? `Naratif AI dimatikan: teks pemohon mengandungi kemungkinan cubaan suntikan arahan (prompt injection). Semakan manual diperlukan.`
    : `${i.fullName} (${i.occupation}) memohon ${rm(i.amount)} untuk tempoh ${i.tenureMonths} bulan melalui ${i.product}. ` +
      `Anggaran ansuran ialah ${rm(installment)}, dengan nisbah khidmat hutang ${pct(dsr)}. ` +
      `Skor kredit ${score}. Saringan Syariah: ${verBM}.` +
      (suggestedProduct ? ` Alternatif patuh Syariah yang dicadangkan: ${suggestedProduct}.` : "") +
      ` Cadangan: ${recBM}. Keputusan muktamad dibuat oleh pegawai.`;

  return { score, band, installment, dsr, factors, shariah, guard, recommendation, suggestedProduct, narrativeEN, narrativeBM };
}
