import crypto from "crypto";

/* DEMO MODE ONLY (no TideCloak configured). A small HMAC-signed token so the server can still
 * verify identity and roles on every request. SIMULATED: replaced by TideCloak-signed JWTs
 * as soon as tidecloak.json is configured. */
const SECRET = process.env.DEMO_SECRET || "bayan-demo-secret-change-me";

export const DEMO_USERS: Record<string, { name: string; roles: string[] }> = {
  aisyah: { name: "Aisyah Rahman", roles: ["applicant", "_tide_vault.selfencrypt", "_tide_vault.selfdecrypt"] },
  "officer.hafiz": { name: "Hafiz Yusoff", roles: ["applicant", "officer"] },
  "auditor.lim": { name: "Mei Ling Lim", roles: ["applicant", "auditor"] },
};

const b64 = (s: string) => Buffer.from(s).toString("base64url");
const sign = (body: string) => crypto.createHmac("sha256", SECRET).update(body).digest("base64url");

export function issueDemoToken(username: string): string | null {
  const u = DEMO_USERS[username];
  if (!u) return null;
  const body = b64(JSON.stringify({ sub: `demo-${username}`, preferred_username: username, roles: u.roles, exp: Math.floor(Date.now() / 1000) + 8 * 3600 }));
  return `demo.${body}.${sign(body)}`;
}

export function verifyDemoToken(token: string): { sub: string; preferred_username: string; roles: string[]; exp: number } | null {
  const [p, body, sig] = (token || "").split(".");
  if (p !== "demo" || !body || !sig) return null;
  const expected = sign(body);
  if (sig.length !== expected.length || !crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return null;
  try {
    const claims = JSON.parse(Buffer.from(body, "base64url").toString());
    if (!claims.exp || claims.exp < Date.now() / 1000) return null;
    return claims;
  } catch {
    return null;
  }
}
