export type Product = "Murabahah" | "Tawarruq" | "Ijarah" | "Conventional loan";

export interface ApplicationInput {
  fullName: string;
  occupation: string;
  monthlyIncome: number; // RM
  incomeMonths: number; // months of verifiable income history
  ewalletInflow: number; // RM / month
  commitments: number; // RM / month existing debt payments
  amount: number; // RM requested
  tenureMonths: number;
  product: Product;
  purpose: string; // free text
}

export interface Factor {
  label: string;
  impact: number; // points added/removed
  note: string;
}

export interface ShariahFinding {
  principle: "Riba" | "Gharar" | "Maysir" | "Haram activity" | "Structure";
  severity: "fail" | "warn";
  detail: string;
}

export interface Assessment {
  score: number; // 300-850
  band: "Low risk" | "Moderate risk" | "High risk";
  installment: number;
  dsr: number; // debt service ratio 0-1+
  factors: Factor[];
  shariah: { verdict: "Compliant" | "Needs review" | "Non-compliant"; findings: ShariahFinding[] };
  guard: { flagged: boolean; reasons: string[] };
  recommendation: "Approve" | "Manual review" | "Decline";
  suggestedProduct: Product | null;
  narrativeEN: string;
  narrativeBM: string;
}

export type Status = "Pending" | "Approved" | "Declined" | "Alternative offered";

export interface Application {
  id: string;
  ownerSub: string;
  ownerUsername: string;
  createdAt: string;
  input: ApplicationInput;
  assessment: Assessment;
  status: Status;
  decision?: { by: string; at: string; note: string; product: Product | null };
}

export interface AuditEntry {
  seq: number;
  ts: string;
  actor: string;
  role: string;
  action: string;
  target: string;
  details: string;
  prevHash: string;
  hash: string;
}

export interface VaultItem {
  id: string;
  label: string;
  ciphertext: string; // Tide-encrypted, server never sees plaintext
  createdAt: string;
}
