import rawConfig from "../tidecloak.json";

/** TideCloak adapter config. `{}` until `npm run init` provisions the realm. */
export const tcConfig = rawConfig as Record<string, any>;

/** True once `npm run init` has written a real adapter config. */
export const isConfigured = Boolean(tcConfig && tcConfig.realm && tcConfig["auth-server-url"]);

/** "tide" = full Tide mode (keyless login, vault encryption, IGA quorum).
 *  "standard" = fallback set up by init/standard-setup.sh when Tide's licence service is unreachable. */
export const tideMode = isConfigured && tcConfig.bayanMode !== "standard";

/** No TideCloak configured: built-in demo login (SIMULATED identity provider). */
export const demoMode = !isConfigured;

/** BAYAN realm roles (created by init/realm.json). */
export const ROLES = {
  applicant: "applicant",
  officer: "officer",
  auditor: "auditor",
} as const;

export type Role = (typeof ROLES)[keyof typeof ROLES];

/** Tag used for Tide self-encryption of each user's private vault. */
export const VAULT_TAG = "vault";
