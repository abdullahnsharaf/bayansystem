import { NextRequest, NextResponse } from "next/server";
import { verifyTideCloakToken } from "@tidecloak/nextjs/server";
import { tcConfig, isConfigured } from "../config";
import { verifyDemoToken } from "../demoToken";

export interface Caller {
  sub: string;
  username: string;
  vuid?: string;
  roles: string[];
}

/**
 * Verifies the caller's TideCloak access token (signature, expiry, issuer)
 * and that it carries at least one of `allowedRoles`.
 * Every API route calls this - the browser UI is never trusted on its own.
 */
export async function requireRole(
  req: NextRequest,
  allowedRoles: string[],
): Promise<{ caller: Caller } | { error: NextResponse }> {
  const header = req.headers.get("authorization") || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : req.cookies.get("kcToken")?.value || "";
  if (!token) {
    return { error: NextResponse.json({ error: "Unauthorised: no token" }, { status: 401 }) };
  }
  if (!isConfigured) {
    // DEMO MODE (SIMULATED identity provider): HMAC-signed demo token, still verified server-side.
    const d = verifyDemoToken(token);
    if (!d) return { error: NextResponse.json({ error: "Unauthorised: invalid or expired demo session" }, { status: 401 }) };
    if (allowedRoles.length && !allowedRoles.some((r) => d.roles.includes(r)))
      return { error: NextResponse.json({ error: "Forbidden: invalid token or missing role" }, { status: 403 }) };
    return { caller: { sub: d.sub, username: d.preferred_username, roles: d.roles } };
  }
  try {
    const claims = (await verifyTideCloakToken(tcConfig as any, token, allowedRoles)) as Record<string, any> | null;
    if (!claims) {
      return { error: NextResponse.json({ error: "Forbidden: invalid token or missing role" }, { status: 403 }) };
    }
    const client = (tcConfig.resource as string) || "";
    const roles = [
      ...((claims.realm_access?.roles as string[]) || []),
      ...((claims.resource_access?.[client]?.roles as string[]) || []),
    ];
    return {
      caller: {
        sub: String(claims.sub),
        username: String(claims.preferred_username || claims.sub),
        vuid: claims.vuid ? String(claims.vuid) : undefined,
        roles,
      },
    };
  } catch {
    return { error: NextResponse.json({ error: "Forbidden: invalid token or missing role" }, { status: 403 }) };
  }
}

/** The role this caller is acting as for audit purposes. */
export function primaryRole(c: Caller): string {
  if (c.roles.includes("officer")) return "officer";
  if (c.roles.includes("auditor")) return "auditor";
  return "applicant";
}
