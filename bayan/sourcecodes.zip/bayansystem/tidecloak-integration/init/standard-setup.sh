#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# BAYAN fallback setup: TideCloak STANDARD sign-in (no Tide licence needed).
#
# Use this when `tcinit.sh` fails at setUpTideRealm because Tide's licence
# service is unreachable (e.g. CreateFreeTierLicense timeout). It provisions
# the same BAYAN realm/roles/client on your TideCloak server, switches the
# login flow to TideCloak's standard username/password flow, creates three
# demo users, and writes tidecloak.json.
#
# Real in this mode : TideCloak login, realm roles, server-side token checks,
#                     page gating, segregation of duties, audit chain.
# Not available     : Tide (keyless) login, Tide vault encryption, IGA quorum.
#                     The app labels these "Tide licence pending".
#
# Run from the project root (Git Bash / WSL / macOS):
#     bash init/standard-setup.sh
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail
SCRIPT_DIR="$(cd -- "$(dirname "${BASH_SOURCE[0]}")" >/dev/null 2>&1 && pwd -P)"

TC_URL="${TIDECLOAK_LOCAL_URL:-http://localhost:8080}"
REALM="${REALM_NAME:-bayan-demo}"
CLIENT="${CLIENT_NAME:-bayan-web}"
APP_URL="${CLIENT_APP_URL:-http://localhost:3000}"
KC_USER="${KC_USER:-admin}"
KC_PASSWORD="${KC_PASSWORD:-password}"
DEMO_PASSWORD="${DEMO_PASSWORD:-Bayan@2026}"
OUT="${SCRIPT_DIR}/../tidecloak.json"
PUBLIC_URL="${TIDECLOAK_PUBLIC_URL:-}"   # e.g. https://xxxx.trycloudflare.com (tunnel to this TideCloak)
EXTRA_APP_URL="${VERCEL_APP_URL:-}"      # e.g. https://bayan.vercel.app

command -v curl >/dev/null || { echo "Missing curl" >&2; exit 1; }
command -v jq   >/dev/null || { echo "Missing jq (winget install jqlang.jq, then reopen the terminal)" >&2; exit 1; }

clean() { tr -d '\r'; }   # Windows jq prints CRLF
token() {
  curl -s -X POST "${TC_URL}/realms/master/protocol/openid-connect/token" \
    -d "username=${KC_USER}" -d "password=${KC_PASSWORD}" -d grant_type=password -d client_id=admin-cli \
    | jq -r .access_token | clean
}
# api METHOD PATH [curl args...]  -> sets CODE and BODY
api() {
  local m="$1" p="$2"; shift 2
  local tmp; tmp="$(mktemp)"
  CODE=$(curl -s -o "$tmp" -w "%{http_code}" -X "$m" "${TC_URL}/admin/realms${p}" -H "Authorization: Bearer $(token)" "$@")
  BODY="$(cat "$tmp")"; rm -f "$tmp"
}

echo "TideCloak: ${TC_URL}   realm: ${REALM}   client: ${CLIENT}   app: ${APP_URL}"
T="$(token)"
[[ -n "$T" && "$T" != "null" ]] || { echo "ERROR: cannot get an admin token. Is TideCloak running at ${TC_URL}? (docker logs mytidecloak)" >&2; exit 1; }

# 1. Realm (same roles/client as the Tide setup)
api GET "/${REALM}"
if [[ "$CODE" == "200" ]]; then
  echo "1/6 realm '${REALM}' already exists - reusing it"
else
  echo "1/6 creating realm '${REALM}'..."
  TMP_REALM="$(mktemp)"
  sed -e "s|http://localhost:3000|${APP_URL}|g" -e "s|nextjs-test|${REALM}|g" -e "s|myclient|${CLIENT}|g" \
      "${SCRIPT_DIR}/realm.json" > "$TMP_REALM"
  api POST "" -H "Content-Type: application/json" --data-binary @"$TMP_REALM"
  rm -f "$TMP_REALM"
  [[ "$CODE" == 2* ]] || { echo "ERROR creating realm (HTTP $CODE): $BODY" >&2; exit 1; }
fi

# 2. Standard browser login flow (the Tide flow needs the licensed Tide IdP)
echo "2/6 switching login to TideCloak standard flow..."
api GET "/${REALM}"
REP="$(echo "$BODY" | jq --arg fu "${PUBLIC_URL%/}" '.browserFlow = "browser" | .registrationAllowed = false | (if $fu != "" then .attributes.frontendUrl = $fu else . end)')"
api PUT "/${REALM}" -H "Content-Type: application/json" --data-binary "$REP"
[[ "$CODE" == 2* ]] || { echo "ERROR updating realm (HTTP $CODE): $BODY" >&2; exit 1; }

# 3. Do not force the "Link Tide account" action on users
echo "3/6 disabling the Link-Tide-account required action..."
api GET "/${REALM}/authentication/required-actions/link-tide-account-action"
if [[ "$CODE" == "200" ]]; then
  RA="$(echo "$BODY" | jq '.enabled = false | .defaultAction = false')"
  api PUT "/${REALM}/authentication/required-actions/link-tide-account-action" -H "Content-Type: application/json" --data-binary "$RA" || true
fi

# 4. Demo users with roles
create_user() {   # username first last role
  local u="$1" f="$2" l="$3" role="$4"
  api GET "/${REALM}/users?username=${u}&exact=true"
  local id; id="$(echo "$BODY" | jq -r '.[0].id // empty' | clean)"
  if [[ -z "$id" ]]; then
    api POST "/${REALM}/users" -H "Content-Type: application/json" \
      -d "{\"username\":\"${u}\",\"email\":\"${u}@bayan.demo\",\"firstName\":\"${f}\",\"lastName\":\"${l}\",\"enabled\":true,\"emailVerified\":true,\"requiredActions\":[]}"
    [[ "$CODE" == 2* ]] || { echo "ERROR creating user ${u} (HTTP $CODE): $BODY" >&2; exit 1; }
    api GET "/${REALM}/users?username=${u}&exact=true"
    id="$(echo "$BODY" | jq -r '.[0].id // empty' | clean)"
  fi
  api PUT "/${REALM}/users/${id}/reset-password" -H "Content-Type: application/json" \
    -d "{\"type\":\"password\",\"value\":\"${DEMO_PASSWORD}\",\"temporary\":false}"
  [[ "$CODE" == 2* ]] || { echo "ERROR setting password for ${u} (HTTP $CODE): $BODY" >&2; exit 1; }
  if [[ -n "$role" ]]; then
    api GET "/${REALM}/roles/${role}"
    local rr="$BODY"
    api POST "/${REALM}/users/${id}/role-mappings/realm" -H "Content-Type: application/json" -d "[${rr}]"
  fi
  echo "     ${u}  (role: ${role:-applicant})"
}
echo "4/6 creating demo users (password: ${DEMO_PASSWORD})..."
create_user "aisyah"        "Aisyah" "Rahman" ""
create_user "officer.hafiz" "Hafiz"  "Yusoff" "officer"
create_user "auditor.lim"   "Mei Ling" "Lim"  "auditor"

# 4b. Allow the app's URLs (local + optional Vercel) on the client
api GET "/${REALM}/clients?clientId=${CLIENT}"
CREP="$(echo "$BODY" | jq '.[0]')"
CID0="$(echo "$CREP" | jq -r '.id' | clean)"
URLS="$(jq -n --arg a "${APP_URL%/}" --arg b "${EXTRA_APP_URL%/}" '[$a, $b, "http://localhost:3000"] | map(select(. != "")) | unique')"
CREP="$(echo "$CREP" | jq --argjson u "$URLS" '.redirectUris = ([$u[] | ., . + "/*", . + "/silent-check-sso.html", . + "/auth/redirect"]) | .webOrigins = $u | .attributes["post.logout.redirect.uris"] = ([$u[] | . + "/*"] | join("##"))')"
api PUT "/${REALM}/clients/${CID0}" -H "Content-Type: application/json" --data-binary "$CREP"
[[ "$CODE" == 2* ]] && echo "     allowed app URLs: $(echo "$URLS" | jq -r 'join(", ")')" || echo "WARN: could not update client URLs (HTTP $CODE)"

# 5. Adapter config -> tidecloak.json (+ accept standard RS256 tokens)
echo "5/6 writing tidecloak.json..."
api GET "/${REALM}/clients?clientId=${CLIENT}"
CID="$(echo "$BODY" | jq -r '.[0].id // empty' | clean)"
[[ -n "$CID" ]] || { echo "ERROR: client ${CLIENT} not found" >&2; exit 1; }
api GET "/${REALM}/clients/${CID}/installation/providers/keycloak-oidc-keycloak-json"
[[ "$CODE" == 2* ]] || { echo "ERROR fetching adapter config (HTTP $CODE): $BODY" >&2; exit 1; }
echo "$BODY" | jq --arg pu "${PUBLIC_URL%/}" '. + {"tokenSignatureAlgorithms": ["RS256","ES256","EdDSA"], "bayanMode": "standard"} | (if $pu != "" then .["auth-server-url"] = ($pu + "/") else . end)' > "$OUT"

# 6. Done
echo "6/6 done."
echo ""
echo "Realm '${REALM}' ready in STANDARD sign-in mode."
echo "Restart the app (Ctrl+C, then bun run dev / npm run dev) and open ${APP_URL}"
echo "Demo logins (password ${DEMO_PASSWORD}):  aisyah = applicant | officer.hafiz = officer | auditor.lim = auditor"
