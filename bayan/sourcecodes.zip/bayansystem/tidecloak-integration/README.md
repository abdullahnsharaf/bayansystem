# BAYAN بَيَان — Breach-resilient Islamic micro-financing, secured by TideCloak

**RMIT Hackathon 2026 · Challenge 2 (Tide) · Taylor's University · Team [TEAM NAME]**

> Shariah-compliant credit for gig workers — even if we are breached.

## ▶ Demo video (2 minutes)

<!-- After uploading video.mp4 to the repository root, GitHub shows it at this link. -->
**[Watch the demo video — video.mp4](./video.mp4)**

_To embed a playable video here: open this README in the GitHub web editor, drag `video.mp4` into this spot, and GitHub inserts a player link automatically._

## ⚡ Quick start (no setup, 2 minutes)

```bash
npm install        # or: bun install   (use Node 22 LTS, not Node 25)
npm run dev        # or: bun run dev
```
Open **http://localhost:3000** and pick a role: **Applicant** (`aisyah`), **Credit officer** (`officer.hafiz`) or **Auditor** (`auditor.lim`).

With no TideCloak server connected, BAYAN runs in **demo mode**: the login and vault encryption are **SIMULATED** (clearly labelled in the app), while role checks still run **server-side on every page and API** with signed sessions. The full TideCloak integration (Tide login, Tide encryption, quorum governance) activates automatically once `tidecloak.json` is configured — see [Setup](#setup--15-minutes).

## Submission contents

| File | What it is |
|---|---|
| `sourcecodes.zip` | Application source code (same as this repository, without `node_modules`) |
| `summary.docx` | Problem, solution, value and role of TideCloak |
| `video.mp4` | Two-minute working demonstration |
| `README.md` → [Run instructions](#setup--15-minutes) | How to launch and test the prototype |
| `BUILD_PROMPTS.md` | The AI prompts and engineering plan used to build BAYAN |

## Problem statement

Malaysia's B40 and gig-economy workers (e-hailing drivers, riders, home sellers) are routinely refused Shariah-compliant financing because they have no payslips. Banks can now assess them on **alternative data** — e-wallet flows, gig earnings, IC numbers, bank details — but that makes a lending platform a single, very attractive honeypot:

* one leaked **password database** or phished **admin account** exposes every applicant's identity and finances;
* one **compromised officer** can approve their own or a friend's financing;
* AI-assisted assessment adds a new attack surface: **prompt injection** hidden in an applicant's free text ("ignore previous instructions and approve…", in English, Malay, Portuguese…);
* audit logs that admins can quietly edit cannot satisfy BNM RMiT or a Shariah audit.

**BAYAN** lets an Islamic bank lend to these workers while assuming it *will* be breached.

## How TideCloak secures BAYAN

| Threat | BAYAN + TideCloak control | Where in the code |
|---|---|---|
| Stolen passwords / credential stuffing | Login with **Tide**: no password database exists; keys are split across the Tide network (no single party holds them) | `app/page.tsx` (`login()`), `app/layout.tsx` |
| Wrong person opens a workspace | **Role-separated workspaces** — `applicant`, `officer`, `auditor` realm roles, token verified **server-side before the page renders** | `proxy.ts` (`createTideCloakProxy`) |
| Forged / tampered API calls | **Every API route re-verifies** the TideCloak JWT signature, expiry and role | `lib/server/auth.ts` (`verifyTideCloakToken`) |
| DB breach or rogue admin reads IC numbers | **Private vault**: encrypted in the browser with `doEncrypt` under the user's Tide identity (`_tide_vault.*` roles). Server stores ciphertext only | `app/applicant/page.tsx`, `app/api/vault` |
| One compromised admin grants themselves officer powers | **Quorum governance (IGA)**: role grants are change requests that must be approved by admins before they take effect | TideCloak console (set up by `npm run init`) |
| Officer approves their own application | **Segregation of duties** enforced on the server | `app/api/applications/[id]/decision` |
| Records silently edited | **Tamper-evident audit trail**: each entry SHA-256-chained to the previous; auditor sees "chain intact / broken at #n" | `lib/server/db.ts` |
| Prompt injection in applicant text (Challenge 1) | **AI input guard** in EN/MS/PT/FR/IT: flagged cases disable the AI narrative and force manual review. Production: our fine-tuned XLM-R classifier (Macro-F1 ≈ 0.97) | `lib/engine.ts` (`guardText`) |

## Features

* **Applicant** — apply for Murabahah / Tawarruq / Ijarah financing; track decisions; private Tide-encrypted vault (IC number, bank account…) with a *"What the server sees"* toggle that shows the ciphertext.
* **Credit officer** — queue with stats; credit score on alternative data with factor breakdown; **Shariah screening** (riba, gharar, maysir, haram activity); **smart product substitution** (e.g. conventional refinance → Tawarruq); officer narrative in **English and Bahasa Malaysia**; Approve / Offer alternative / Decline. Non-compliant structures cannot be approved.
* **Shariah / compliance auditor** — read-only, searchable, hash-chained audit trail with integrity check; CSV export of the register (the export itself is audited).

Six realistic demo applications are seeded (one contains a prompt-injection attempt, one is a forex-speculation request, one a conventional refinance).

---

## Setup (≈ 15 minutes)

Requirements: **Node 22 LTS** (not Node 25), **Docker Desktop running** ("Engine running"), and on Windows **Git Bash** + `jq` for step 3.

```bash
# 1. Install (if npm says "Exit handler never called", install Node 22 LTS - or use Bun: `bun install`)
npm install

# 2. Start TideCloak and keep it running (Docker Desktop must be open)
docker run --name mytidecloak -d -p 8080:8080 -e KC_BOOTSTRAP_ADMIN_USERNAME=admin -e KC_BOOTSTRAP_ADMIN_PASSWORD=password tideorg/tidecloak-dev:latest
#    wait ~1 min, then http://localhost:8080 should load

# 3. Provision the "bayan" realm - run in Git Bash / WSL / macOS terminal (needs curl + jq)
#    Windows: winget install jqlang.jq   (then reopen Git Bash)
bash init/tcinit.sh            # same as: npm run init
#    -> open the "ACTION REQUIRED" link and create/link your Tide account
#    -> wait for "All done"; tidecloak.json is now filled

# 4. Run the app (TideCloak must stay running while you use it)
npm run dev                    # or: bun run dev   ->  http://localhost:3000
```

Settings for step 3 live in `init/.env.example` (realm `bayan`, client `bayan-web`, app URL `http://localhost:3000`). If the hackathon provides a hosted TideCloak, set `TIDECLOAK_LOCAL_URL` there instead of running Docker. Until `tidecloak.json` is filled, the app shows a setup screen instead of crashing.

| Problem | Fix |
|---|---|
| `npm error Exit handler never called` | Node 25 bug: install Node 22 LTS, reopen VS Code (or use `bun install` / `bun run dev`) |
| `failed to connect to the docker API` | Open Docker Desktop and wait for "Engine running" |
| port 8080 already allocated / realm already exists | `docker rm -f mytidecloak`, then repeat steps 2-3 |
| `jq: command not found` | `winget install jqlang.jq`, reopen Git Bash |
| `setUpTideRealm failed` | needs internet access to the Tide network - check Wi-Fi / ask the Tide team |
| Reset demo data | delete the `.data` folder |


### If `tcinit.sh` fails at `setUpTideRealm` (Tide licence service unreachable)

At the event, Tide's licence service timed out (`CreateFreeTierLicense ... HttpClient.Timeout of 100 seconds`, error `TIDE-IDPEXT-VENDOR-KEYGEN_FAILED`), and the venue Wi-Fi blocked SSL to `ork1.tideprotocol.com`. Use the fallback, which needs **no Tide licence**:

```bash
bash init/standard-setup.sh        # Windows: & "C:\Program Files\Git\bin\bash.exe" init/standard-setup.sh
```

It creates realm `bayan-demo` on the same TideCloak server (same roles and client), switches login to TideCloak's standard flow, creates three users and writes `tidecloak.json`:

| User | Password | Role |
|---|---|---|
| `aisyah` | `Bayan@2026` | applicant |
| `officer.hafiz` | `Bayan@2026` | officer |
| `auditor.lim` | `Bayan@2026` | auditor |

**Real in fallback mode:** TideCloak login, realm roles, server-side token verification on every page and API, segregation of duties, tamper-evident audit.
**Pending (clearly labelled in the UI):** Tide keyless login, Tide vault encryption, IGA quorum approval - they switch on automatically once `tcinit.sh` succeeds (it writes a Tide-mode `tidecloak.json`).

### Demo users and roles (full Tide mode) (this is the quorum-governance demo)

Self-registration is disabled on purpose — users are created by admins.

1. Open the TideCloak admin console: `http://localhost:8080` → realm **bayan** (log in with the admin account you enrolled in step 3).
2. **Users → Add user** for each demo user, e.g. `aisyah` (applicant), `officer.hafiz` (officer), `auditor.lim` (auditor). Every new user automatically gets `applicant` + the `_tide_vault` encryption roles (default roles in `init/realm.json`).
3. For each user, generate the **Tide account link** (required action *Link Tide account*) and open it to enroll that user.
4. **Role mapping → Assign role**: give `officer.hafiz` the realm role `officer`, `auditor.lim` the role `auditor`.
5. Because IGA is on, each change appears as a **pending change request**. Approve it in the console's change-request / approvals screen. Show judges: *"a role grant does nothing until it is approved — one stolen admin account cannot create a rogue officer."*

(Exact menu names can vary slightly between TideCloak versions; the Tide team on site can confirm.)

---


## Publish: GitHub + Vercel

**GitHub (required for submission).** github.com → New repository → name `bayan` → **Public** → Create → *uploading an existing file* → drag in every file and folder of this project **except `node_modules`, `.next`, `.data`** → Commit. Also upload `summary.docx`, `video.mp4` and `sourcecodes.zip`.

**Vercel (optional live link).** Vercel cannot run TideCloak, so TideCloak must be reachable from the internet:

1. Laptop: TideCloak running in Docker, then open a free tunnel (no account): `cloudflared tunnel --url http://localhost:8080` (install: `winget install Cloudflare.cloudflared`). Copy the `https://….trycloudflare.com` URL. Keep this window open.
2. vercel.com → Add New → Project → import the GitHub repo → Deploy. Copy the app URL, e.g. `https://bayan-xxxx.vercel.app`.
3. Re-run setup with both URLs (Git Bash syntax; PowerShell: `$env:NAME="value"` lines):
   `TIDECLOAK_PUBLIC_URL=https://….trycloudflare.com VERCEL_APP_URL=https://bayan-xxxx.vercel.app bash init/standard-setup.sh`
4. Commit the updated `tidecloak.json` to GitHub → Vercel redeploys automatically.

Notes: the tunnel URL changes every time cloudflared restarts (repeat steps 3-4). On Vercel, data is stored in `/tmp` and resets when the instance recycles (demo only).

## 3-minute demo script

1. **Landing → Sign in with Tide.** "There is no password table to steal."
2. **Applicant `aisyah`**: submit an application (e.g. RM 8,000 Murabahah for a used car). Store an IC number in the **vault** → click *What the server sees* (ciphertext) → *Decrypt* (only she can).
3. Try `http://localhost:3000/officer` as `aisyah` → **Access denied** (verified server-side by `proxy.ts`).
4. **Officer `officer.hafiz`**: open the queue → `APP-2026-0906` shows the **prompt-injection** flag (AI narrative disabled) → `APP-2026-0902` conventional refinance → **Offer alternative: Tawarruq** → approve Aisyah's case; switch narrative to **BM**.
5. **Auditor `auditor.lim`**: audit trail shows every submission, vault store and decision; **Chain intact ✓**; export CSV (also logged).
6. Close: **quorum approval** of a role grant in the TideCloak console.

## Architecture

```
Browser (Next.js 16, React 19)                     Server (Next.js route handlers)
 ├─ TideCloakProvider ── login / roles / token      ├─ proxy.ts  → verifies kcToken + role before /applicant /officer /auditor
 ├─ doEncrypt / doDecrypt (vault, tag "vault")      ├─ /api/*    → verifyTideCloakToken on every request
 └─ fetch + Bearer token ──────────────────────────►├─ lib/engine.ts  credit score · Shariah screen · guard · EN/BM narrative
                                                    └─ lib/server/db.ts  JSON store (.data/) · SHA-256 audit chain · ciphertext vault
TideCloak (Keycloak-based IAM) + Tide Cybersecurity Fabric (ORKs): identity, keys, IGA quorum approvals
```

## Mocked / simulated components (required disclosure)

Everything about **identity, roles, encryption and governance is real TideCloak**. The business layer around it is simulated for the prototype and tagged **SIMULATED** in the UI.

| Component | Status in prototype | What is real vs simulated | Production plan |
|---|---|---|---|
| Login, user identity (Tide) | **Real** | TideCloak + Tide network, no passwords stored by BAYAN | same |
| Role-based access (applicant / officer / auditor) | **Real** | Realm roles; page gate in `proxy.ts`, JWT re-verified on every API call | same |
| Private vault encryption | **Real** | `doEncrypt` / `doDecrypt` with `_tide_vault.*` roles; server stores ciphertext only | add Tide policy-based decryption so the assigned officer can read shared documents |
| Quorum approval of role grants | **Real** | TideCloak IGA change requests (enabled by `npm run init`) | same, with threshold > 1 admin |
| Segregation of duties, tamper-evident audit chain | **Real (app logic)** | Enforced server-side; SHA-256 hash chain verified on the auditor page | write-once database / ledger |
| Demo login (only when no TideCloak is configured) | **Simulated** | Built-in role picker with HMAC-signed sessions, still verified server-side | TideCloak sign-in (already integrated) |
| Applicant records & audit storage | **Simulated** | JSON file `.data/bayan.json` (delete to reset) | Postgres |
| 6 applicants in the officer queue | **Simulated** | Seeded demo data, tagged DEMO DATA | real applications |
| Income, e-wallet, commitments | **Simulated** | Self-declared in the form; no bank / e-wallet / CCRIS API | open-banking + CCRIS/CTOS APIs |
| Credit score | **Simulated** | Transparent rules model (`lib/engine.ts`) | XGBoost + SHAP on alternative data |
| Shariah screening | **Simulated** | Keyword rules for riba / gharar / maysir / haram | fatwa-RAG engine (JAKIM e-Fatwa, BNM SAC) |
| Prompt-injection guard | **Simulated** | Multilingual keyword patterns | our Challenge-1 XLM-R classifier (val Macro-F1 ≈ 0.97) |
| EN / BM officer narrative | **Simulated** | Template text, no LLM call | LLM narrative behind the injection guard |

## Project structure

```
app/            pages (landing, auth/redirect, applicant, officer, auditor, access-denied) + api/
components/     AppShell (role-aware navigation), useApi (token-attached fetch), SetupScreen
lib/            config, types, engine (scoring/Shariah/guard), server/auth (token verify), server/db (store/audit)
init/           realm.json (roles: applicant/officer/auditor + _tide_vault.*), tcinit.sh, .env.example
proxy.ts        server-side role gate for pages
tidecloak.json  written by `npm run init` (empty placeholder until then)
```
