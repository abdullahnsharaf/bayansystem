// Server-side page protection: the access token (kcToken cookie) is verified BEFORE a role's page renders.
// - TideCloak configured: TideCloak-signed JWT via createTideCloakProxy.
// - Demo mode (no TideCloak): HMAC-signed demo token (SIMULATED identity provider), same role rules.
import type { NextRequest } from "next/server";
import { NextResponse } from "next/server";
import { createTideCloakProxy } from "@tidecloak/nextjs/server";
import type { TidecloakConfig } from "@tidecloak/nextjs/server";
import rawConfig from "./tidecloak.json";
import { verifyDemoToken } from "./lib/demoToken";

const tcConfig = rawConfig as TidecloakConfig;
const configured = Boolean((tcConfig as any).realm);
const RULES: Record<string, string> = { "/applicant": "applicant", "/officer": "officer", "/auditor": "auditor" };

const tideProxy = configured
  ? createTideCloakProxy({
      config: tcConfig,
      protectedRoutes: { "/applicant": ["applicant"], "/officer": ["officer"], "/auditor": ["auditor"] },
      onFailure: (ctx: { token: string | null }, req: NextRequest) =>
        NextResponse.redirect(new URL(ctx.token ? `/access-denied?from=${req.nextUrl.pathname}` : "/", req.url)),
      onError: (_err: unknown, req: NextRequest) => NextResponse.redirect(new URL("/auth/redirect?auth=failed", req.url)),
    })
  : null;

export async function proxy(req: NextRequest) {
  if (tideProxy) return tideProxy(req);
  const path = req.nextUrl.pathname;
  const needed = Object.entries(RULES).find(([p]) => path === p || path.startsWith(p + "/"))?.[1];
  if (!needed) return NextResponse.next();
  const claims = verifyDemoToken(req.cookies.get("kcToken")?.value || "");
  if (!claims) return NextResponse.redirect(new URL("/", req.url));
  if (!claims.roles.includes(needed)) return NextResponse.redirect(new URL(`/access-denied?from=${path}`, req.url));
  return NextResponse.next();
}

export const config = {
  matcher: ["/applicant/:path*", "/officer/:path*", "/auditor/:path*", "/applicant", "/officer", "/auditor"],
};
