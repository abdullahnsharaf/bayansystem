"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import type { ReactNode } from "react";
import { useTideCloak } from "@/components/auth";
import { Logo } from "./SetupScreen";
import IdentityPanel from "./IdentityPanel";
import { tideMode, demoMode } from "@/lib/config";

const NAV = [
  { href: "/applicant", label: "My financing", role: "applicant", icon: "◐" },
  { href: "/officer", label: "Officer queue", role: "officer", icon: "▤" },
  { href: "/auditor", label: "Audit trail", role: "auditor", icon: "⛓" },
];

export default function AppShell({ title, subtitle, children }: { title: string; subtitle?: string; children: ReactNode }) {
  const { authenticated, isInitializing, logout, hasRealmRole, getValueFromIdToken } = useTideCloak();
  const path = usePathname();

  if (isInitializing) return <div className="center-page muted">Verifying your Tide identity…</div>;
  if (!authenticated)
    return (
      <div className="center-page">
        <div className="card">
          <p>Your session has ended.</p>
          <Link className="btn" href="/">
            Sign in again
          </Link>
        </div>
      </div>
    );

  const roles = NAV.filter((n) => hasRealmRole(n.role));
  const name = getValueFromIdToken("preferred_username") || "user";

  return (
    <div className="shell">
      <aside className="sidebar">
        <Logo size={34} />
        <nav>
          {roles.map((n) => (
            <Link key={n.href} href={n.href} className={path?.startsWith(n.href) ? "active" : ""}>
              <span className="ico">{n.icon}</span>
              {n.label}
            </Link>
          ))}
        </nav>
        <div className="side-foot">
          <div className="tide-badge" title="Keys for this session are split across the Tide network - no single party holds them.">
            <span className="dot" /> {demoMode ? "Demo mode · TideCloak-ready" : "Secured by TideCloak"}
          </div>
          <div className="who">
            <strong>{name}</strong>
            <span>{NAV.filter((n) => hasRealmRole(n.role)).map((n) => n.role).join(" · ") || "no BAYAN role"}</span>
          </div>
          <button className="btn ghost full" onClick={() => logout()}>
            Sign out
          </button>
        </div>
      </aside>
      <main className="content">
        <div className="proto-banner">
          Prototype · items tagged <span className="sim">SIMULATED</span> are mocked (demo data, rules engine, file store).{" "}
          {demoMode
            ? "Demo login and vault encryption are SIMULATED (no TideCloak server connected); role checks still run server-side on every request. TideCloak integration activates when tidecloak.json is configured."
            : tideMode
            ? "Identity, roles, encryption and governance are real TideCloak."
            : "Login, roles and server-side token checks are real TideCloak (standard sign-in). Tide keyless login, vault encryption and quorum approval: Tide licence pending."}
        </div>
        <header className="page-head">
          <div>
            <h1>{title}</h1>
            {subtitle && <p className="muted">{subtitle}</p>}
          </div>
          <IdentityPanel />
        </header>
        {children}
      </main>
    </div>
  );
}

export function Badge({ kind, children }: { kind: "ok" | "warn" | "bad" | "info" | "muted"; children: ReactNode }) {
  return <span className={`badge ${kind}`}>{children}</span>;
}

export const statusKind = (s: string) =>
  s === "Approved" ? "ok" : s === "Declined" ? "bad" : s === "Alternative offered" ? "info" : "warn";
export const recKind = (s: string) => (s === "Approve" ? "ok" : s === "Decline" ? "bad" : "warn");
export const shariahKind = (s: string) => (s === "Compliant" ? "ok" : s === "Non-compliant" ? "bad" : "warn");
export const money = (n: number) => `RM ${Math.round(n).toLocaleString("en-MY")}`;
