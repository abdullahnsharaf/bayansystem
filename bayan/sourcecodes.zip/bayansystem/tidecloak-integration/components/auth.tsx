"use client";
/* One auth hook for the whole app.
 * - TideCloak configured  -> the real @tidecloak/nextjs hook.
 * - Not configured (demo) -> a demo provider with the SAME shape, so every page works unchanged.
 * `isConfigured` is a build-time constant, so the hook choice never changes between renders. */
import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { useTideCloak as useRealTideCloak } from "@tidecloak/nextjs";
import { isConfigured } from "@/lib/config";

type AuthShape = {
  authenticated: boolean;
  isInitializing: boolean;
  token: string | null;
  tokenExp?: number;
  login: (username?: string) => void | Promise<void>;
  logout: () => void | Promise<void>;
  refreshToken?: () => Promise<unknown>;
  hasRealmRole: (role: string) => boolean;
  getValueFromIdToken: (key: string) => any;
  doEncrypt: (items: { data: string; tags: string[] }[]) => Promise<string[]>;
  doDecrypt: (items: { encrypted: string; tags: string[] }[]) => Promise<string[]>;
};

const DemoCtx = createContext<AuthShape | null>(null);
const KEY = "bayan-demo-token";

function decode(token: string | null): { preferred_username?: string; roles?: string[]; exp?: number; sub?: string } {
  try {
    return token ? JSON.parse(atob(token.split(".")[1].replace(/-/g, "+").replace(/_/g, "/"))) : {};
  } catch {
    return {};
  }
}

/* SIMULATED vault crypto for demo mode: AES-GCM with a per-user key derived in the browser.
 * The server still only receives ciphertext. Production = Tide doEncrypt (no key held anywhere). */
async function userKey(username: string) {
  const raw = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(`bayan-vault:${username}`));
  return crypto.subtle.importKey("raw", raw, "AES-GCM", false, ["encrypt", "decrypt"]);
}
const toB64 = (b: Uint8Array) => btoa(String.fromCharCode(...b));
const fromB64 = (s: string) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));

export function DemoAuthProvider({ children }: { children: ReactNode }) {
  const [token, setToken] = useState<string | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    try {
      setToken(sessionStorage.getItem(KEY));
    } catch {}
    setReady(true);
  }, []);

  const claims = useMemo(() => decode(token), [token]);
  const valid = Boolean(token && claims.exp && claims.exp > Date.now() / 1000);

  const login = useCallback(async (username?: string) => {
    if (!username) {
      window.location.href = "/";
      return;
    }
    const res = await fetch("/api/demo-login", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ username }) });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "Login failed");
    try {
      sessionStorage.setItem(KEY, data.token);
    } catch {}
    setToken(data.token);
  }, []);

  const logout = useCallback(async () => {
    try {
      sessionStorage.removeItem(KEY);
    } catch {}
    await fetch("/api/demo-login", { method: "DELETE" }).catch(() => {});
    setToken(null);
    window.location.href = "/";
  }, []);

  const value: AuthShape = {
    authenticated: valid,
    isInitializing: !ready,
    token: valid ? token : null,
    tokenExp: claims.exp,
    login,
    logout,
    refreshToken: async () => true,
    hasRealmRole: (r) => valid && (claims.roles || []).includes(r),
    getValueFromIdToken: (k) => (k === "preferred_username" ? claims.preferred_username : k === "sub" ? claims.sub : undefined),
    doEncrypt: async (items) => {
      const key = await userKey(claims.preferred_username || "");
      return Promise.all(
        items.map(async ({ data }) => {
          const iv = crypto.getRandomValues(new Uint8Array(12));
          const ct = new Uint8Array(await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, new TextEncoder().encode(data)));
          return `demoenc.${toB64(iv)}.${toB64(ct)}`;
        }),
      );
    },
    doDecrypt: async (items) => {
      const key = await userKey(claims.preferred_username || "");
      return Promise.all(
        items.map(async ({ encrypted }) => {
          const [, iv, ct] = encrypted.split(".");
          const pt = await crypto.subtle.decrypt({ name: "AES-GCM", iv: fromB64(iv) }, key, fromB64(ct));
          return new TextDecoder().decode(pt);
        }),
      );
    },
  };
  return <DemoCtx.Provider value={value}>{children}</DemoCtx.Provider>;
}

function useDemo(): AuthShape {
  const v = useContext(DemoCtx);
  if (!v) throw new Error("DemoAuthProvider missing");
  return v;
}

/** Drop-in replacement for @tidecloak/nextjs useTideCloak. */
export const useTideCloak: () => AuthShape = isConfigured ? (useRealTideCloak as unknown as () => AuthShape) : useDemo;
