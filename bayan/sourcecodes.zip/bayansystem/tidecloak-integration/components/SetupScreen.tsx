// Shown only until `npm run init` writes tidecloak.json.
export default function SetupScreen() {
  return (
    <main className="center-page">
      <div className="card setup">
        <Logo />
        <h1>Connect BAYAN to TideCloak</h1>
        <p className="muted">tidecloak.json is still empty. Provision the realm once:</p>
        <ol>
          <li>
            Start TideCloak:
            <pre>{`docker run --name mytidecloak -d -p 8080:8080 \\
  -e KC_BOOTSTRAP_ADMIN_USERNAME=admin -e KC_BOOTSTRAP_ADMIN_PASSWORD=password \\
  tideorg/tidecloak-dev:latest`}</pre>
          </li>
          <li>
            Run <code>npm run init</code> and open the Tide enrollment link it prints.
          </li>
          <li>
            Restart <code>npm run dev</code> and refresh this page.
          </li>
        </ol>
        <p className="muted small">See README.md for the full guide (roles, demo users, quorum approval).</p>
      </div>
    </main>
  );
}

export function Logo({ size = 40 }: { size?: number }) {
  return (
    <div className="logo">
      <svg width={size} height={size} viewBox="0 0 48 48" aria-hidden>
        <circle cx="24" cy="24" r="22" fill="var(--green)" />
        <path d="M30 10a15 15 0 1 0 0 28a12 12 0 1 1 0-28z" fill="var(--gold)" />
        <rect x="21" y="21" width="9" height="9" rx="1.5" transform="rotate(45 25.5 25.5)" fill="#fff" opacity=".9" />
      </svg>
      <span>
        BAYAN <em>بَيَان</em>
      </span>
    </div>
  );
}
