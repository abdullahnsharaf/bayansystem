"use client";
import { useEffect, useState } from "react";
import { useTideCloak } from "@/components/auth";
import { useApi } from "./useApi";
import { demoMode } from "@/lib/config";

interface Me {
  sub: string;
  username: string;
  vuid?: string;
  roles: string[];
}

/** Shows what TideCloak verified ON THE SERVER for this request - makes the trust layer visible. */
export default function IdentityPanel() {
  const api = useApi();
  const { token, tokenExp } = useTideCloak() as any;
  const [me, setMe] = useState<Me | null>(null);
  const [err, setErr] = useState("");

  useEffect(() => {
    if (!token) return;
    api<Me>("/api/me")
      .then((m) => {
        setMe(m);
        setErr("");
      })
      .catch((e) => setErr(e.message));
  }, [token, api]);

  const bayanRoles = (me?.roles || []).filter((r) => ["applicant", "officer", "auditor"].includes(r));
  const vaultRoles = (me?.roles || []).filter((r) => r.startsWith("_tide_vault"));
  const exp = typeof tokenExp === "number" ? new Date(tokenExp * 1000).toLocaleTimeString() : null;

  return (
    <div className={`card identity ${err ? "bad" : ""}`}>
      <div className="id-head">
        <span className="dot" />
        <strong>{err ? "Identity not verified" : demoMode ? "Verified server-side (demo login)" : "Verified by TideCloak (server-side)"}</strong>
      </div>
      {err ? (
        <p className="err-text small">{err}</p>
      ) : !me ? (
        <p className="muted small">Verifying token signature, expiry and roles…</p>
      ) : (
        <dl>
          <dt>User</dt>
          <dd>{me.username}</dd>
          <dt>Tide vuid</dt>
          <dd className="mono" title={me.vuid}>{me.vuid ? `${me.vuid.slice(0, 10)}…${me.vuid.slice(-6)}` : demoMode ? "- (demo login)" : "- (Tide licence pending)"}</dd>
          <dt>BAYAN roles</dt>
          <dd>{bayanRoles.join(", ") || "none"}</dd>
          <dt>Encryption rights</dt>
          <dd>{vaultRoles.length ? (me.vuid ? "vault encrypt / decrypt" : demoMode ? "vault (simulated encryption)" : "granted - needs Tide licence") : "none"}</dd>
          {exp && (
            <>
              <dt>Token expires</dt>
              <dd>{exp}</dd>
            </>
          )}
        </dl>
      )}
    </div>
  );
}

/** Marks prototype parts that are mocked or simulated (required by the Challenge 2 brief). */
export function Sim({ children = "SIMULATED", title }: { children?: string; title?: string }) {
  return (
    <span className="sim" title={title || "Mocked or simulated in this prototype - see README 'Mocked / simulated components'"}>
      {children}
    </span>
  );
}
