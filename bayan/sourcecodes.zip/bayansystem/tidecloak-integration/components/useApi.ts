"use client";
import { useCallback } from "react";
import { useTideCloak } from "@/components/auth";

/** fetch() wrapper that attaches the TideCloak access token. The server re-verifies it. */
export function useApi() {
  const { token, refreshToken } = useTideCloak();
  return useCallback(
    async <T = any,>(url: string, init: RequestInit = {}): Promise<T> => {
      try {
        await refreshToken?.();
      } catch {
        /* token still valid or refresh not needed */
      }
      const res = await fetch(url, {
        ...init,
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}`, ...(init.headers || {}) },
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error((data as any).error || `${res.status} ${res.statusText}`);
      return data as T;
    },
    [token, refreshToken],
  );
}
